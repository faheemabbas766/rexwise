<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

_deprecated_file( 'ReduxCore/core/required.php', '4.3', 'redux-core/inc/classes/class-redux-required.php', 'This file has been discontinued and is no longer used in Redux 4.  Please remove any references to it as it will be removed in future versions of Redux.' );

