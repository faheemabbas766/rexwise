<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class About_Us extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_about_us';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine About Us', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
	
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'about_us',
            [
                'label' => esc_html__( 'About Us', 'braine' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
					'4' => esc_html__( 'Style Four ', 'braine'),
					'5' => esc_html__( 'Style Five ', 'braine'),
					'6' => esc_html__( 'Style Six ', 'braine'),
					'7' => esc_html__( 'Style Seven ', 'braine'),
				),
			]
		);
		
		$this->add_control(
            'show_shapes',
			[
				'label' => __( 'Enable/Disable Shape Images', 'braine' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [ 'active' => true, ],
				'condition' => [ 'layout_control' => ['1', '3'], ],
			]
		);
		$this->add_control(
			'image_title',
			[
				'label'       => __( 'Image Caption ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 
					'layout_control' => ['3'],
					'show_shapes' => 'yes', 
				],
				'default' => esc_html__( 'AI AGENT', 'braine' ),
				'placeholder' => __( 'Enter your Image Caption', 'braine' ),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
				'condition' => [ 
					'layout_control' => ['1', '3'],
					'show_shapes' => 'yes', 
				],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
				'condition' => [ 
					'layout_control' => ['1', '3'],
					'show_shapes' => 'yes', 
				],
			]
		);
		$this->add_control(
			'image3',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
				'condition' => [ 
					'layout_control' => ['1', '3'],
					'show_shapes' => 'yes', 
				],
			]
		);
		$this->add_control(
			'image4',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1', '2', '3', '4'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'image5',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1', '2', '4', '6'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2', '3', '4', '6', '7'], ],
				'default' => esc_html__( 'About us', 'braine' ),
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2', '3', '4', '5', '6', '7'], ],
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Crafting of your digital <span>narrative discover</span> our journey', 'braine' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '3', '4', '6'], ],
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2', '3', '4', '6'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['1', '2', '3', '4', '6'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'btn_title2',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['3', '4'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link2',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['3', '4'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'avg_rating',
			[
				'label' => esc_html__( 'Avg Rating', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => esc_html__( 'Enter your Count Title', 'braine' ),
				'default' => esc_html__( '4.7', 'braine' ),
			]
		);
		$this->add_control(
			'rating_title',
			[
				'label' => esc_html__( 'Rating Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => esc_html__( 'Enter your Count Title', 'braine' ),
				'default' => esc_html__( 'Customer rating', 'braine' ),
			]
		);
		$this->add_control(
			'features_list',
			[
				'label' => esc_html__( 'Feature List', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['2', '3', '4'], ],
				'placeholder' => esc_html__( 'Enter your Feature List', 'braine' ),
			]
		);
		
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'block_title5',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_text5',
			[
				'label'       => __( 'Description', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_features_list5',
			[
				'label'       => __( 'Feature List', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_btn_title5',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_btn_link5',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);	
		$repeater->add_control(
			'feature_image5',
			[
				'label' => __( 'Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'slide',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['5'], ],
			]
		);
		
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'select_style',
			[
				'label'   => esc_html__( 'Choose Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style Star Icons ', 'braine'),
					'2' => esc_html__( 'Style Active Box ', 'braine'),
					'3' => esc_html__( 'Style Normal Box ', 'braine'),
				),
			]
		);
		$repeater->add_control(
			'block_title7',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_text7',
			[
				'label'       => __( 'Description', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'braine' ),
			]
		);
		$this->add_control(
			'slide_v7',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['7'], ],
			]
		);
		$this->end_controls_section();
		
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
			
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');		
	?>
    
	<?php if($settings['layout_control'] == '7'): ?>
    
    <!-- Choose One -->
	<section class="choose-two te-icon-box">
		<div class="auto-container">
            <?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <!-- Sec Title -->
            <div class="sec-title style-three light centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="row clearfix">
				<?php foreach($settings['slide_v7'] as $key => $item): ?>
				<?php if($item['select_style'] == '3'):?>
                <!-- Choose Block One -->
				<div class="choose-block_one col-lg-4 col-md-6 col-sm-12">
					<div class="choose-block_one-inner">
						<div class="choose-block_one-icon">
							<i class="icon-user-3"></i>
						</div>
						<div class="choose-block_one-title"><?php echo wp_kses($item['block_title7'], true ) ;?></div>
						<div class="choose-block_one-text"><?php echo wp_kses($item['block_text7'], true ) ;?></div>
					</div>
				</div>
                
                <?php elseif($item['select_style'] == '2'):?>
                <!-- Choose Block One -->
				<div class="choose-block_one active col-lg-4 col-md-6 col-sm-12">
					<div class="choose-block_one-inner">
						<div class="choose-block_one-icon">
							<i class="icon-hand-star"></i>
						</div>
						<div class="choose-block_one-title"><?php echo wp_kses($item['block_title7'], true ) ;?></div>
						<div class="choose-block_one-text"><?php echo wp_kses($item['block_text7'], true ) ;?></div>
					</div>
				</div>
                <?php else: ?>
                <!-- Choose Block One -->
				<div class="choose-block_one col-lg-4 col-md-6 col-sm-12">
					<div class="choose-block_one-inner">
						<div class="choose-block_one-rating">
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
						</div>
						<div class="choose-block_one-title"><?php echo wp_kses($item['block_title7'], true ) ;?></div>
						<div class="choose-block_one-text"><?php echo wp_kses($item['block_text7'], true ) ;?></div>
					</div>
				</div>
                <?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<!-- End Choose One -->
    
	<?php elseif($settings['layout_control'] == '6'): ?>
	
    <!-- Story One -->
	<section class="story-one te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<?php if($settings['image5']['id']){ ?>
				<!-- Image Column -->
				<div class="story-one_image-column col-lg-6 col-md-12 col-sm-12">
					<div class="story-one_image-outer">
						<div class="story-one_image">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
					</div>
				</div>
				<?php } ?>
				<!-- Image Column -->
				<div class="story-one_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="story-one_content-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                        <!-- Sec Title -->
						<div class="sec-title style-four">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
						</div>
                        <?php } ?>
						<?php echo wp_kses($settings['text'], true ) ;?>
						<?php if($settings[ 'btn_title']) {?>
                        <div class="story-one_button">
							<a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
								</span>
							</a>
						</div>
                        <?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Assistance One -->
    
	<?php elseif($settings['layout_control'] == '5'): ?>
	
    <!-- Data One -->
	<section class="data-one te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'title']) {?>
            <!-- Sec Title -->
			<div class="sec-title style-three centered">
				<div class="sec-title_icon">
					<i class="fab fa-font-awesome fa-fw"></i>
				</div>
				<h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2>
			</div>
			<?php } ?>
			<div class="data-blocks_outer">
				<?php $i = 1; $count = 0; foreach($settings['slide'] as $key => $item): ?>
				<?php if($count % 2) { ?>
                
                <!-- Data Block One -->
				<div class="data-block_one">
					<div class="data-block_one-inner">
						<div class="row clearfix">							
							<!-- Content Column -->
							<div class="data-block_one-content-column col-lg-6 col-md-12 col-sm-12">
								<div class="data-block_one-content">
									<div class="data-block_one-number"><?php $i = sprintf('%02d', $i); echo $i; ?></div>
									<h3 class="data-block_one-title"><?php echo wp_kses( $item[ 'block_title5'], true  );?></h3>
									<div class="data-block_one-text"><?php echo wp_kses( $item[ 'block_text5'], true  );?></div>
									<?php $features_list = $item['block_features_list5'];
										if(!empty($features_list)){
										$features_list = explode("\n", ($features_list)); 
									?>
									<ul class="data-block_one-list">
										<?php foreach($features_list as $features): ?>
										   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
										<?php endforeach; ?>
									</ul>
									<?php } ?>
                                    <?php if($item[ 'block_btn_title5']) { ?>
									<div class="data-block_one-button">
										<a href="<?php echo esc_url( $item['block_btn_link5']['url']);?>" class="template-btn btn-style-one">
											<span class="btn-wrap">
												<span class="text-one"><?php echo wp_kses( $item[ 'block_btn_title5'], true  );?></span>
												<span class="text-two"><?php echo wp_kses( $item[ 'block_btn_title5'], true  );?></span>
											</span>
										</a>
									</div>
                                    <?php } ?>
								</div>
							</div>
							<?php if($item['feature_image5']['id']){ ?>
							<!-- Image Column -->
							<div class="data-block_one-image-column col-lg-6 col-md-12 col-sm-12">
								<div class="data-block_one-image">
									<img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
								</div>
							</div>
							<?php } ?>
						</div>
					</div>
				</div> 
                
                <?php } else { ?>
                
                <!-- Data Block One -->
				<div class="data-block_one">
					<div class="data-block_one-inner">
						<div class="row clearfix">
							<?php if($item['feature_image5']['id']){ ?>
                            <!-- Image Column -->
							<div class="data-block_one-image-column col-lg-6 col-md-12 col-sm-12">
								<div class="data-block_one-image">
									<img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
								</div>
							</div>
                            <?php } ?>
							<!-- Content Column -->
							<div class="data-block_one-content-column col-lg-6 col-md-12 col-sm-12">
								<div class="data-block_one-content">
									<div class="data-block_one-number"><?php $i = sprintf('%02d', $i); echo $i; ?></div>
									<h3 class="data-block_one-title"><?php echo wp_kses( $item[ 'block_title5'], true  );?></h3>
									<div class="data-block_one-text"><?php echo wp_kses( $item[ 'block_text5'], true  );?></div>
									<?php $features_list = $item['block_features_list5'];
										if(!empty($features_list)){
										$features_list = explode("\n", ($features_list)); 
									?>
									<ul class="data-block_one-list">
										<?php foreach($features_list as $features): ?>
										   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
										<?php endforeach; ?>
									</ul>
									<?php } ?>
                                    <?php if($item[ 'block_btn_title5']) { ?>
									<div class="data-block_one-button">
										<a href="<?php echo esc_url( $item['block_btn_link5']['url']);?>" class="template-btn btn-style-one">
											<span class="btn-wrap">
												<span class="text-one"><?php echo wp_kses( $item[ 'block_btn_title5'], true  );?></span>
												<span class="text-two"><?php echo wp_kses( $item[ 'block_btn_title5'], true  );?></span>
											</span>
										</a>
									</div>
                                    <?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
                               
                <?php } ?>
                <?php $i++; $count++; endforeach; ?>
    		</div>
    	</div>
    </section>
	<?php elseif($settings['layout_control'] == '4'): ?>
    
    <!-- Conversation One -->
	<section class="conversation-one te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">				
				<!-- Content Column -->
				<div class="conversation-one_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="conversation-one_content-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                        <!-- Sec Title -->
						<div class="sec-title style-two title-anim">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                            <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
						</div>
                        <?php } ?>
                        <?php $features_list = $settings['features_list'];
							if(!empty($features_list)){
							$features_list = explode("\n", ($features_list)); 
						?>
						<ul class="livechat-list">
							<?php foreach($features_list as $features): ?>
							   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
							<?php endforeach; ?>
						</ul>
						<?php } ?>
                        <?php if($settings[ 'btn_title'] || $settings[ 'btn_title2']) {?>
						<div class="livechat-options d-flex align-items-center flex-wrap">
							<?php if($settings[ 'btn_title']) {?>
                            <div class="livechat_button">
                                <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
                                    <span class="btn-wrap">
                                        <span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
                                        <span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
                                    </span>
                                </a>                            
                            </div>
                            <?php } ?>
                            <?php if($settings[ 'btn_title2']) {?>
							<a class="livechat-now" href="<?php echo esc_url($settings['btn_link2']['url']) ;?>"><i><img src="<?php echo esc_url(wp_get_attachment_url($settings['image4']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></i> <?php echo wp_kses($settings['btn_title2'], true ) ;?></a>
							<?php } ?>
                        </div>
                        <?php } ?>
					</div>
				</div>
				<?php if($settings['image5']['id']){ ?>
				<!-- Image Column -->
				<div class="conversation-one_chat-column col-lg-6 col-md-12 col-sm-12">
					<div class="conversation-one_chat-outer">
						<div class="conversation-one_image">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
	</section>
	<!-- End Conversation -->
    
    <?php elseif($settings['layout_control'] == '3'): ?>
    
    <!-- LiveChat -->
	<section class="livechat te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<?php if($settings[ 'show_shapes']) {?>
				<!-- Image Column -->
				<div class="livechat_image-column col-lg-6 col-md-12 col-sm-12">
					<div class="livechat_image-outer">
						<?php if($settings[ 'image_title']) {?>
                        <div class="livechat-agent"><i><img src="<?php echo esc_url(get_template_directory_uri());?>/assets/images/icons/livechat-stars.png" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></i> <?php echo wp_kses($settings['image_title'], true ) ;?></div>
						<?php } ?>
                        <div class="livechat-layer" <?php if($settings['image']['id']){ ?>style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
						<div class="livechat-icon" <?php if($settings['image2']['id']){ ?>style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"<?php } ?>></div>
						<div class="color-layer"></div>
						<?php if($settings['image3']['id']){ ?>
                        <img src="<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
                        <?php } ?>
					</div>
				</div>
				<?php } ?>
				<!-- Content Column -->
				<div class="livechat_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="livechat_content-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                        <!-- Sec Title -->
						<div class="sec-title style-two title-anim">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                            <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
						</div>
                        <?php } ?>
                        <?php $features_list = $settings['features_list'];
							if(!empty($features_list)){
							$features_list = explode("\n", ($features_list)); 
						?>
						<ul class="livechat-list">
							<?php foreach($features_list as $features): ?>
							   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
							<?php endforeach; ?>
						</ul>
						<?php } ?>
                        <?php if($settings[ 'btn_title'] || $settings[ 'btn_title2']) {?>
						<div class="livechat-options d-flex align-items-center flex-wrap">
							<?php if($settings[ 'btn_title']) {?>
                            <div class="livechat_button">					
                                <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
                                    <span class="btn-wrap">
                                        <span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
                                        <span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
                                    </span>
                                </a>                            
                            </div>
                            <?php } ?>
                            <?php if($settings[ 'btn_title2']) {?>
							<a class="livechat-now" href="<?php echo esc_url($settings['btn_link2']['url']) ;?>"><i><img src="<?php echo esc_url(wp_get_attachment_url($settings['image4']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></i> <?php echo wp_kses($settings['btn_title2'], true ) ;?></a>
							<?php } ?>
                        </div>
                        <?php } ?>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End LiveChat -->
    
	<?php elseif($settings['layout_control'] == '2'): ?>
    
    <!-- Answer One -->
	<section class="answer-one te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Tab Column -->
				<div class="answer-one_title-column col-lg-5 col-md-12 col-sm-12">
					<div class="answer-one_title-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                        <!-- Sec Title -->
						<div class="sec-title title-anim">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
						</div>
                        <?php } ?>
                        <?php $features_list = $settings['features_list'];
							if(!empty($features_list)){
							$features_list = explode("\n", ($features_list)); 
						?>
						<ul class="answer-one_list">
							<?php foreach($features_list as $features): ?>
							   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
							<?php endforeach; ?>
						</ul>
						<?php } ?>
                        <?php if($settings[ 'btn_title']) {?>
						<div class="answer-one_button">							
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
								</span>
							</a>                            
						</div>
                        <?php } ?>
					</div>
				</div>
				<?php if($settings['image4']['id'] || $settings['image5']['id']){ ?>
				<!-- Tab Column -->
				<div class="answer-one_content-column col-lg-7 col-md-12 col-sm-12">
					<div class="answer-one_content-outer">
						<div class="answer-one_pattern" <?php if($settings['image4']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image4']['id'])); ?>)"<?php } ?>></div>
						<?php if($settings['image5']['id']){ ?>
                        <div class="answer-one_image">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>	
                        <?php } ?>	
					</div>
				</div>
                <?php } ?>
			</div>
		</div>
	</section>
	<!-- End Answer One -->
    
    <?php else:	?>
    
    <!-- About One -->
	<section class="about-one te-icon-box">
		<?php if($settings[ 'show_shapes']) {?>
        <div class="about-one_pattern" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
		<div class="about-one_icon" <?php if($settings['image2']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"<?php } ?>></div>
		<div class="about-one_icon-two" <?php if($settings['image3']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>)"<?php } ?>></div>
		<?php } ?>
        <div class="auto-container">
			<div class="row clearfix">
				<?php if($settings['image4']['id'] || $settings['image5']['id']){ ?>
				<!-- Tab Column -->
				<div class="about-one_tab-column col-xl-6 col-lg-6 col-md-12 col-sm-12">
					<div class="about-one_tab-outer">
						<div class="about-one_tab-shadow" <?php if($settings['image4']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image4']['id'])); ?>)"<?php } ?>></div>
						<?php if($settings['image5']['id']){ ?>
                        <div class="about-one_tab-image">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
                        <?php } ?>
					</div>
				</div>
				<?php } ?>
				<!-- Tab Column -->
				<div class="about-one_content-column col-xl-6 col-lg-6 col-md-12 col-sm-12">
					<div class="about-one_content-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                        <!-- Sec Title -->
						<div class="sec-title">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
						</div>
                        <?php } ?>
						<?php echo wp_kses($settings['text'], true ) ;?>
						<div class="about-one_options d-flex align-items-center flex-wrap">
							<?php if($settings[ 'btn_title']) {?>
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
								</span>
							</a>
                            <?php } ?>
                            <?php if($settings[ 'avg_rating'] || $settings['rating_title']) {?>
							<div class="about-one_rating-box d-flex align-items-center flex-wrap">
								<?php echo wp_kses($settings['avg_rating'], true ) ;?>
								<div class="about-one_rating">
									<span class="fa fa-star"></span>
									<span class="fa fa-star"></span>
									<span class="fa fa-star"></span>
									<span class="fa fa-star"></span>
									<span class="fa fa-star"></span>
									<i><?php echo wp_kses($settings['rating_title'], true ) ;?></i>
								</div>
							</div>
                            <?php } ?>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End About One -->
    
    <?php endif; ?>  
    <?php 
    }
}