<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Testimonials_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_testimonials_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Testimonials Grid', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'testimonials_grid',
            [
                'label' => esc_html__( 'Testimonials Grid', 'braine' ),
            ]
        );
		
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default', 'braine' ),
					'one' => esc_html__( 'One Column Grid ', 'braine'),
					'two'  => esc_html__( 'Two Column Grid', 'braine' ),
					'three'  => esc_html__( 'Three Column Grid', 'braine' ),
					'four'  => esc_html__( 'Four Column Grid', 'braine' ),
					'five'  => esc_html__( 'Six Column Grid', 'braine' ),
				),
			]
		);	
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'braine' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'braine' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'braine' ),
                    'title'      => esc_html__( 'Title', 'braine' ),
                    'menu_order' => esc_html__( 'Menu Order', 'braine' ),
                    'rand'       => esc_html__( 'Random', 'braine' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'braine' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'braine' ),
                    'ASC'  => esc_html__( 'ASC', 'braine' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT2,
				'label' => esc_html__('Category', 'braine'),
				'label_block' => true,
				'multiple' 	=> true,
				'options' => get_testimonials_categories()
            ]
        );		
		$this->add_control(
            'show_pagination',
			[
				'label' => __( 'Enable/Disable Pagination', 'braine' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enable/Disable Pagination', 'braine' ),
			]
		);
		$this->end_controls_section();
		
		/************************************************************************
									Tab Style Start
		*************************************************************************/
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .braine-testi-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .braine-testi-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .braine-testi-section',				
			]
		);
		$this->end_controls_section();		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		
		$grid_col = $settings[ 'col_grid' ];
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-3 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-4 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}	
				
		$paged = get_query_var('paged');
		$paged = braine_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;
		
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-braine' );
        
		$args = array(
			'post_type'      => 'testimonials',
			'posts_per_page' => braine_set( $settings, 'query_number' ),
			'orderby'        => braine_set( $settings, 'query_orderby' ),
			'order'          => braine_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( braine_set( $settings, 'query_category' ) ) $args['testimonials_cat'] = braine_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	{ ?>   
    
    <!-- Testimonial Four -->
	<section class="testimonial-four braine-testi-section">
		<div class="auto-container">
			<div class="row clearfix">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
				<!-- Testimonial Block One -->
				<div class="testimonial-block_one <?php echo esc_attr( $classes );?>">
					<div class="testimonial-block_one-inner">
						<div class="testimonial-block_one-rating">
							<?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
								if(!empty($rating)){
								for ($x = 1; $x <= 5; $x++) {
									if($x <= $rating) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>';
								}
							} ?>
						</div>
						<div class="testimonial-block_one-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
						<div class="testimonial-block_one-author_box">
							<div class="testimonial-block_one-author-image">
								<?php the_post_thumbnail('braine_60x60'); ?>
							</div>
							<?php the_title(); ?> <span><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
						</div>
					</div>
				</div>
                <?php endwhile; ?>
			</div>
			<?php if($settings['show_pagination']) { ?>
			<!-- Styled Pagination -->
			<div class="styled-pagination text-center">
				<?php braine_the_pagination2(array('total'=>$query->max_num_pages, 'next_text' => '<i class="fa fa-angle-right"></i>', 'prev_text' => '<i class="fa fa-angle-left fa-fw"></i>')); ?>
			</div>
			<!-- End Styled Pagination -->
			<?php } ?>
		</div>
	</section>
	<!-- End Testimonial Four -->
            
   	 <?php }
	 wp_reset_postdata();
	}
}