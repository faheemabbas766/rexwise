<?php

namespace BRAINEPLUGIN\Element;


class Elementor {
	static $widgets = array(
		//Home Page One
		'banner_slider',
		'service_grid',
		'about_us',
		'our_funfacts',
		'our_features',
		'pricing_tab',
		'faqs',
		'testimonials_carousel',
		'instagram_section',
		'blog_carousel',
		
		//Home Page Two
		'banner',
		'clients_section',
		'cta_section',
		'testimonials_grid',
		'team_carousel',
		'blog_grid',
		'video_section',
		'team_grid',
		'contact_info',
		'form',
		'google_map',
		
		
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = BRAINEPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\BRAINEPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'braine',
			[
				'title' => esc_html__( 'Braine', 'braine' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'templatepath',
			[
				'title' => esc_html__( 'Template Path', 'braine' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();