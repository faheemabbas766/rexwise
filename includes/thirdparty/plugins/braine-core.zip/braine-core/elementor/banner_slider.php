<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Banner_Slider extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_banner_slider';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Banner Slider', 'braine' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-banner';
    }

    
    public function get_categories() {
        return [ 'braine' ];
    }
	
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'banner_slider',
            [
                'label' => esc_html__( 'Banner Slider', 'braine' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
				),
			]
		);
		
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'image',
			[
				'label' => __( 'Icon Image One', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'image2',
			[
				'label' => __( 'Icon Image Two', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'image3',
			[
				'label' => __( 'Pattern Image One', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'image4',
			[
				'label' => __( 'Pattern Image Two', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'image5',
			[
				'label' => __( 'Pattern Image Three', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'image6',
			[
				'label' => __( 'Sub Title Icon Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => __( 'Description', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'braine' ),
			]
		);
		$repeater->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$repeater->add_control(
			'video_link',
			[
				'label' => __( 'Video Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);	
		$repeater->add_control(
			'image7',
			[
				'label' => __( 'Pattern Image Four', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'image8',
			[
				'label' => __( 'Icon Image Four', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'author_name',
			[
				'label'       => __( 'Author Name', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Author Name', 'braine' ),
			]
		);
		$repeater->add_control(
			'author_designation',
			[
				'label'       => __( 'Author Designation', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Author Designation', 'braine' ),
			]
		);
		$repeater->add_control(
			'percentage',
			[
				'label'       => __( 'Percentage Value', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Percentage Value', 'braine' ),
			]
		);
		$repeater->add_control(
			'percentage_text',
			[
				'label'       => __( 'Percentage Text', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Percentage Text', 'braine' ),
			]
		);
		$repeater->add_control(
			'percentage2',
			[
				'label'       => __( 'Percentage Value', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Percentage Value', 'braine' ),
			]
		);
		$repeater->add_control(
			'value',
			[
				'label'       => __( 'Value', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Value', 'braine' ),
			]
		);
		$repeater->add_control(
			'goal_title',
			[
				'label'       => __( 'Goal Title', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Goal Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'image9',
			[
				'label' => __( 'Icon Image Five', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);		
		$repeater->add_control(
			'banner_image',
			[
				'label' => __( 'Banner Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'slide',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['1'], ],
			]
		);		
		
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'subtitle2',
			[
				'label'       => __( 'Sub Title', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'title2',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'text2',
			[
				'label'       => __( 'Description', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'braine' ),
			]
		);
		$repeater->add_control(
			'btn_title2',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'braine' ),
			]
		);
		$repeater->add_control(
			'btn_link2',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);	
		$repeater->add_control(
			'banner_image2',
			[
				'label' => __( 'Banner Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'slide_v2',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['2'], ],
			]
		);		
		$this->end_controls_section();
		
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();	
			
	}

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');		
	?>
    
    <?php if($settings['layout_control'] == '2'): ?>
    
    <!-- Slider Two -->
	<section class="slider-two te-icon-box">
		<div class="main-slider swiper-container">
			<div class="swiper-wrapper">
				<?php foreach($settings['slide_v2'] as $key => $item): ?>
				<!-- Slide -->
				<div class="swiper-slide">
					<div class="auto-container">
						<div class="row clearfix">
							<!-- Content Column -->
							<div class="slider-two_content col-lg-6 col-md-12 col-sm-12">
								<div class="slider-two_content-inner">
									<div class="slider-two_title"><?php echo wp_kses( $item[ 'subtitle2'], true  );?></div>
									<h1 class="slider-two_heading"><?php echo wp_kses( $item[ 'title2'], true  );?></h1>
									<div class="slider-two_text"><?php echo wp_kses( $item[ 'text2'], true  );?></div>
									<?php if($item[ 'btn_title2']) { ?>
                                    <div class="slider-two_button">
										<a href="<?php echo esc_url( $item['btn_link2']['url']);?>" class="template-btn btn-style-three">
											<span class="btn-wrap">
												<span class="text-one"><?php echo wp_kses( $item[ 'btn_title2'], true  );?></span>
												<span class="text-two"><?php echo wp_kses( $item[ 'btn_title2'], true  );?></span>
											</span>
										</a>
									</div>
                                    <?php } ?>
								</div>
							</div>
                            <?php if($item[ 'banner_image2' ]['id']){ ?>
							<!-- Image Column -->
							<div class="slider-two_image-column col-lg-6 col-md-12 col-sm-12">
								<div class="slider-two_image-outer">
									<div class="slider-two_image">
										<img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image2' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
									</div>
								</div>
							</div>
                            <?php } ?>
						</div>
						<div class="slider-two_arrow scroll-to-target" data-target=".members-one">
							<i class="fa fa-arrow-down fa-fw"></i>
						</div>
					</div>
				</div>
                <?php endforeach; ?>
			</div>
		</div>
	</section>
	<!-- End Main Slider Section -->
    
    <?php else: ?>
    
    <!-- Slider One -->
	<section class="slider-one te-icon-box">
		<div class="main-slider swiper-container">
			<div class="swiper-wrapper">
				<?php foreach($settings['slide'] as $key => $item): ?>
				<!-- Slide -->
				<div class="swiper-slide">
					<?php if($item[ 'image' ]['id']){ ?><div class="slider-one_icon" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'image' ]['id'] ) );?>)"></div><?php } ?>
					<?php if($item[ 'image2' ]['id']){ ?><div class="slider-one_icon-two" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'image2' ]['id'] ) );?>)"></div><?php } ?>
					<?php if($item[ 'image3' ]['id']){ ?><div class="slider-one_pattern" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'image3' ]['id'] ) );?>)"></div><?php } ?>
					<?php if($item[ 'image4' ]['id']){ ?><div class="slider-one_pattern-two" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'image4' ]['id'] ) );?>)"></div><?php } ?>
					<?php if($item[ 'image5' ]['id']){ ?><div class="slider-one_pattern-four" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'image5' ]['id'] ) );?>)"></div><?php } ?>
					<div class="auto-container">
						<div class="row clearfix">
							<!-- Content Column -->
							<div class="slider-one_content col-lg-7 col-md-12 col-sm-12">
								<div class="slider-one_content-inner">
									<?php if($item[ 'subtitle' ] || $item[ 'image5' ]['id']){ ?>
                                    <div class="slider-one_title"><?php if($item[ 'image5' ]['id']){ ?><i><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'image6' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></i><?php } ?> <?php echo wp_kses( $item[ 'subtitle'], true  );?></div>
									<?php } ?>
                                    <h1 class="slider-one_heading"><?php echo wp_kses( $item[ 'title'], true  );?></h1>
									<div class="slider-one_text"><?php echo wp_kses( $item[ 'text'], true  );?></div>
									<div class="slider-one_button d-flex align-items-center flex-wrap">
										<?php if($item[ 'btn_title']) { ?>
                                        <a href="<?php echo esc_url( $item['btn_link']['url']);?>" class="template-btn btn-style-one">
											<span class="btn-wrap">
												<span class="text-one"><?php echo wp_kses( $item[ 'btn_title'], true  );?></span>
												<span class="text-two"><?php echo wp_kses( $item[ 'btn_title'], true  );?></span>
											</span>
										</a>
                                        <?php } ?>
                                        <?php if($item['video_link']['url']) { ?>
										<div class="slider-one_video">
											<a href="<?php echo esc_url( $item['video_link']['url']);?>" class="lightbox-video play-box"><span class="fa fa-play"></span></a>
										</div>
                                        <?php } ?>
									</div>
								</div>
							</div>
							<!-- Image Column -->
							<div class="slider-one_image-column col-lg-5 col-md-12 col-sm-12">
								<?php if($item[ 'image7' ]['id']){ ?><div class="slider-one_pattern-three" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'image7' ]['id'] ) );?>)"></div><?php } ?>
								<div class="slider-one_image-outer">
									<?php if($item[ 'author_name'] || $item[ 'author_designation'] || $item[ 'image8' ]['id']) { ?>
                                    <!-- Slider One Author -->
									<div class="slider-one_author">
										<?php if($item[ 'image8' ]['id']){ ?><i><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'image8' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></i><?php } ?>
										<?php if($item[ 'author_name']) { ?><h5 class="slider-one_author-name"><?php echo wp_kses( $item[ 'author_name'], true  );?></h5><?php } ?>
										<?php if($item[ 'author_designation']) { ?><div class="slider-one_author-text"><?php echo wp_kses( $item[ 'author_designation'], true  );?></div><?php } ?>
									</div>
                                    <?php } ?>
                                    <?php if($item[ 'percentage'] || $item[ 'percentage_text']) { ?>
									<!-- Slider One Percent -->
									<div class="slider-one_percentage">
										<i class="fas fa-arrow-up fa-fw"></i>
										<?php if($item[ 'percentage']) { ?><div class="slider-one_percent"><?php echo wp_kses( $item[ 'percentage'], true  );?></div><?php } ?>
										<?php if($item[ 'percentage_text']) { ?><div class="slider-one_percentage-text"><?php echo wp_kses( $item[ 'percentage_text'], true  );?></div><?php } ?>
									</div>
                                    <?php } ?>
                                    <?php if($item[ 'image9' ]['id'] || $item[ 'goal_title'] || $item[ 'value'] || $item[ 'percentage2']){ ?>
									<div class="slider-one_graph">
										<div class="slider-one_graph-title"><?php echo wp_kses( $item[ 'goal_title'], true  );?> <span><?php echo wp_kses( $item[ 'value'], true  );?> <?php if($item[ 'percentage2']) { ?><sup><i class="fas fa-caret-up fa-fw"></i><?php echo wp_kses( $item[ 'percentage2'], true  );?></sup><?php } ?></span></div>
										<?php if($item[ 'image9' ]['id']){ ?><img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'image9' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /><?php } ?>
									</div>
                                    <?php } ?>
                                    <?php if($item[ 'banner_image' ]['id']){ ?>
									<div class="slider-one_image">
										<img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
									</div>
                                    <?php } ?>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<!-- End Main Slider Section -->
    
    <?php endif; ?>
    <?php
    }
}
