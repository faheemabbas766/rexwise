<?php
namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Team_Carousel extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'braine_team_carousel';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Braine Team Carousel', 'braine' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-parallax';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'braine' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'team_carousel',
			[
				'label' => esc_html__( 'Team Carousel', 'braine' ),
			]
		);	
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default' => esc_html__( 'Our team', 'braine' ),
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Team behind the <span>innovation</span>', 'braine' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Vitae mattis dolor sit amet consectetur adipiscing elit Ut et massa Aliquam hendrerit urna.Maecenas vitae mattis tellus.', 'braine' ),
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'braine' ),
					'title'      => esc_html__( 'Title', 'braine' ),
					'menu_order' => esc_html__( 'Menu Order', 'braine' ),
					'rand'       => esc_html__( 'Random', 'braine' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'braine' ),
					'ASC'  => esc_html__( 'ASC', 'braine' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'braine'),
			  'label_block' => true,
			  'options' => get_team_categories()
			]
		);
		$this->end_controls_section();
				
		/************************************************************************
									Tab Style Start
		*************************************************************************/
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .braine-testi-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .braine-testi-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .braine-testi-section',				
			]
		);
		$this->end_controls_section();		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		
        $paged = get_query_var('paged');
		$paged = braine_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;
		
		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-braine' );
		$args = array(
			'post_type'      =>  'team',
			'posts_per_page' => braine_set( $settings, 'query_number' ),
			'orderby'        => braine_set( $settings, 'query_orderby' ),
			'order'          => braine_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		
		if( braine_set( $settings, 'query_category' ) ) $args['team_cat'] = braine_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );
		if ( $query->have_posts() ) 
		{ ?>        
        
        <!-- Team One -->
        <section class="team-one braine-testi-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!-- Title Column -->
                    <div class="team-one_title-column col-lg-4 col-md-12 col-sm-12">
                        <div class="team-one_title-outer">
                            <?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                            <!-- Sec Title -->
                            <div class="sec-title style-four">
                                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
								<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                                <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
                            </div>
                            <?php } ?>
                            <!-- If we need navigation buttons -->
                            <div class="team-one_arrows">
                                <div class="team_carousel-prev fas fa-angle-left fa-fw"></div>
                                <div class="team_carousel-next fas fa-angle-right fa-fw"></div>
                            </div>
                        </div>
                    </div>
    
                    <!-- Team Column -->
                    <div class="team-one_team-column col-lg-8 col-md-12 col-sm-12">
                        <div class="team-one_team-outer">
                            <div class="team-carousel swiper-container">
                                <div class="swiper-wrapper">
                    				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
                                    <!-- Slide -->
                                    <div class="swiper-slide">
                                        <!-- Team Block One -->
                                        <div class="team-block_one">
                                            <div class="team-block_one-inner">
                                                <div class="team-block_one-image">
                                                    <a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_post_thumbnail('braine_420x445'); ?></a>
                                                </div>
                                                <div class="team-block_one-content">
                                                    <h4 class="team-block_one-title"><a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
                                                    <div class="team-block_one-designation"><?php echo (get_post_meta( get_the_id(), 'designation', true ));?></div>
                                                    <?php
														$icons = get_post_meta(get_the_id(), 'social_media_tabs', true); if ($icons) : 
													?>
													<!-- Social Box -->
													<div class="team-block_one-socials">
														<?php
															for ( $i=0; $i < count( $icons['select_social_media'] ); $i++ ) {
															$social_icon = ( isset( $icons['select_social_media'][$i] ) && !empty( $icons['select_social_media'][$i] ) ) ? $icons['select_social_media'][$i] : '';
															$social_link = ( isset( $icons['link_social_media'][$i] ) && !empty( $icons['link_social_media'][$i] ) ) ? $icons['link_social_media'][$i] : '';
														?>
														<a target="_blank" href="<?php echo esc_url($social_link); ?>"><i class="fab <?php echo esc_attr(str_replace("fa ", " ", $social_icon)); ?>"></i></a>
														<?php } ?>
													</div>
													<?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
    								<?php endwhile; ?>
                                </div>
                            </div>
    
                        </div>
                    </div>    
                </div>
            </div>
        </section>
        <!-- End Team One -->
                     
		<?php }
		wp_reset_postdata();
	}
}