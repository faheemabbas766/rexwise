<?php

namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Testimonials_Carousel extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'braine_testimonials_carousel';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Braine Testimonials Carousel', 'braine' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'braine' ];
	}
		
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'testimonials_carousel',
			[
				'label' => esc_html__( 'Testimonials Carousel', 'braine' ),
			]
		);
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
					'4' => esc_html__( 'Style Four ', 'braine'),
				),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],				
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'braine' ),
					'title'      => esc_html__( 'Title', 'braine' ),
					'menu_order' => esc_html__( 'Menu Order', 'braine' ),
					'rand'       => esc_html__( 'Random', 'braine' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'braine' ),
					'ASC'  => esc_html__( 'ASC', 'braine' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT2,
			  'label' => esc_html__('Category', 'braine'),
			  'label_block' => true,
			  'multiple' => true,
			  'options' => get_testimonials_categories(),
			]
		);	
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
				
        $paged = braine_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-braine' );
		$args = array(
			'post_type'      => 'testimonials',
			'posts_per_page' => braine_set( $settings, 'query_number' ),
			'orderby'        => braine_set( $settings, 'query_orderby' ),
			'order'          => braine_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( braine_set( $settings, 'query_category' ) ) $args['testimonials_cat'] = braine_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	 { ?>
    
    <?php if($settings['layout_control'] == '4') :?>
    
    <!-- Testimonial Three -->
	<section class="testimonial-three te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <div class="sec-title style-four centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>			
			<div class="three-item_carousel">
				<div class="swiper-wrapper">
					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
					<!-- Slide -->
					<div class="swiper-slide">
						<!-- Testimonial Block One -->
						<div class="testimonial-block_one">
							<div class="testimonial-block_one-inner">
								<div class="testimonial-block_one-rating">
									<?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
										if(!empty($rating)){
										for ($x = 1; $x <= 5; $x++) {
											if($x <= $rating) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>';
										}
									} ?>
								</div>
								<div class="testimonial-block_one-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
								<div class="testimonial-block_one-author_box">
									<div class="testimonial-block_one-author-image">
										<?php the_post_thumbnail('braine_60x60'); ?>
									</div>
									<?php the_title(); ?> <span><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
								</div>
							</div>
						</div>
					</div>
                    <?php endwhile; ?>
				</div>
				
				<!-- If we need pagination -->
				<div class="three-item_carousel-pagination"></div>
                
			</div>
		</div>
	</section>
	<!-- End Testimonial Three --> 
     
	<?php elseif($settings['layout_control'] == '3') :?>
    
    <!-- Testimonial Three -->
	<section class="testimonial-three te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <div class="sec-title style-three centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>			
			<div class="three-item_carousel">
				<div class="swiper-wrapper">
					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
					<!-- Slide -->
					<div class="swiper-slide">
						<!-- Testimonial Block One -->
						<div class="testimonial-block_one">
							<div class="testimonial-block_one-inner">
								<div class="testimonial-block_one-rating">
									<?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
										if(!empty($rating)){
										for ($x = 1; $x <= 5; $x++) {
											if($x <= $rating) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>';
										}
									} ?>
								</div>
								<div class="testimonial-block_one-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
								<div class="testimonial-block_one-author_box">
									<div class="testimonial-block_one-author-image">
										<?php the_post_thumbnail('braine_60x60'); ?>
									</div>
									<?php the_title(); ?> <span><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
								</div>
							</div>
						</div>
					</div>
                    <?php endwhile; ?>
				</div>
				
				<!-- If we need pagination -->
				<div class="three-item_carousel-pagination"></div>
                
			</div>
		</div>
	</section>
	<!-- End Testimonial Three -->
    
	<?php elseif($settings['layout_control'] == '2') :?>
    
    <!-- Testimonial Two -->
	<section class="testimonial-two te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <div class="sec-title style-two">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="inner-container">
				<div class="single-item_carousel swiper-container">
					<div class="swiper-wrapper">
						<?php while ( $query->have_posts() ) : $query->the_post(); ?>
						<!-- Slide -->
						<div class="swiper-slide">
							<!-- Testimonial Block Two -->
							<div class="testimonial-block_two">
								<div class="testimonial-block_two-inner">
									<div class="row clearfix">
										<!-- Content Column -->
										<div class="testimonial-block_two-content-column col-lg-7 col-md-12 col-sm-12">
											<div class="testimonial-block_two-content-outer">
												<div class="testimonial-block_two-rating">
													<?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
														if(!empty($rating)){
														for ($x = 1; $x <= 5; $x++) {
															if($x <= $rating) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>';
														}
													} ?>
												</div>
												<div class="testimonial-block_two-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
												<div class="testimonial-block_two-author_box">
													<div class="testimonial-block_two-author-image">
														<?php the_post_thumbnail('braine_60x60'); ?>
													</div>
													<?php the_title(); ?> <span><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
												</div>
											</div>
										</div>
                                        <?php $testi_images = get_post_meta( get_the_id(), 'testi_images', true ); ?>
										<!-- Image Column -->
										<div class="testimonial-block_two-image-column col-lg-5 col-md-8 col-sm-12">
											<div class="testimonial-block_two-image-outer">
												<div class="testimonial-block_two-quote fas fa-quote-left fa-fw"></div>
												<div class="testimonial-block_two-image">
													<img src="<?php echo wp_get_attachment_url($testi_images['id']);?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
												</div>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
                        <?php endwhile; ?>					
					</div>
				</div>
			</div>
			<!-- If we need pagination -->
			<div class="single-item_carousel-pagination"></div>
			<div class="testimonial-two_arrows">
				<!-- If we need navigation buttons -->
				<div class="single-item_carousel-prev fas fa-angle-left fa-fw"></div>
				<div class="single-item_carousel-next fas fa-angle-right fa-fw"></div>
			</div>
		</div>
	</section>
	<!-- End Testimonial Two -->
    
    <?php else: ?>
    
    <!-- Testimonial One -->
	<section class="testimonial-one te-icon-box">
		<div class="auto-container">
			<div class="inner-container" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>>
				<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                <div class="sec-title centered">
                    <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                    <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                </div>
                <?php } ?>
				<div class="three-item_carousel swiper-container">
					<div class="swiper-wrapper">
						<?php while ( $query->have_posts() ) : $query->the_post(); ?>
						<!-- Slide -->
						<div class="swiper-slide">
							<!-- Testimonial Block One -->
							<div class="testimonial-block_one">
								<div class="testimonial-block_one-inner">
									<div class="testimonial-block_one-rating">
										<?php $rating = get_post_meta( get_the_id(), 'testimonial_rating', true );
											if(!empty($rating)){
											for ($x = 1; $x <= 5; $x++) {
												if($x <= $rating) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>';
											}
										} ?>
									</div>
									<div class="testimonial-block_one-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
									<div class="testimonial-block_one-author_box">
										<div class="testimonial-block_one-author-image">
											<?php the_post_thumbnail('braine_60x60'); ?>
										</div>
										<?php the_title(); ?> <span><?php echo (get_post_meta( get_the_id(), 'author_designation', true)); ?></span>
									</div>
								</div>
							</div>
						</div>
						<?php endwhile; ?>
					</div>
					
                    <!-- If we need pagination -->
					<div class="three-item_carousel-pagination"></div>
                    
				</div>
			</div>
		</div>
	</section>
	<!-- End Testimonial One -->
    
    <?php endif; ?>
    
    <?php } 
    wp_reset_postdata();
	}

}
