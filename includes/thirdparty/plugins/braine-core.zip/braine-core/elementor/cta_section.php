<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Cta_Section extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_cta_section';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine CTA Section', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
	
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'cta_section',
            [
                'label' => esc_html__( 'CTA Section', 'braine' ),
            ]
        );	
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
					'4' => esc_html__( 'Style Four ', 'braine'),
				),
			]
		);
		$this->add_control(
			'icon_image',
			[
				'label' => esc_html__( 'Icon Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['4'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2', '3'], ],
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['2', '3'], ],
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['2', '3', '4'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['2', '3', '4'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'btn_title2',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['4'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link2',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['4'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'form_url',
			[
				'label' => esc_html__( 'MailChimp Form Url', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [ 'layout_control' => ['1'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your MailChimp Form Url', 'braine' ),
			]
		);	
		$this->add_control(
			'features_list',
			[
				'label' => esc_html__( 'Feature List', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'braine' ),
				'default' => esc_html__( 'Add Your Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->end_controls_section();
		
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
			
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');		
	?>
    
    <?php if($settings['layout_control'] == '4') :?>
    
    <!-- CTA Four -->
	<section class="cta-four te-icon-box">
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings['image']['id']){ ?><div class="cta-three_image-layer" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"></div><?php } ?>
				<?php if($settings['icon_image']['id']){ ?>
                <div class="cta-four_icon">
					<img src="<?php echo esc_url(wp_get_attachment_url($settings['icon_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
				</div>
                <?php } ?>
				<?php if($settings[ 'title']) {?><h2 class="cta-four_title"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
				<?php if($settings[ 'btn_title'] || $settings[ 'btn_title2']) {?>
                <div class="cta-four_buttons d-flex align-items-center justify-content-center flex-wrap">
					<?php if($settings[ 'btn_title']) {?>
                    <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
						<span class="btn-wrap">
							<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
							<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
						</span>
					</a>
                    <?php } ?>
                    <?php if($settings[ 'btn_title2']) {?>
					<a href="<?php echo esc_url($settings['btn_link2']['url']) ;?>" class="template-btn btn-style-two">
						<span class="btn-wrap">
							<span class="text-one"><?php echo wp_kses($settings['btn_title2'], true ) ;?></span>
							<span class="text-two"><?php echo wp_kses($settings['btn_title2'], true ) ;?></span>
						</span>
					</a>
                    <?php } ?>
				</div>
                <?php } ?>
			</div>
		</div>
	</section>
	<!-- End CTA Four -->
    
    <?php elseif($settings['layout_control'] == '3') :?>
    
    <!-- CTA Three -->
	<section class="cta-three te-icon-box">
		<div class="auto-container">
			<div class="inner-container">
				<div class="row clearfix">
					<?php if($settings['image']['id']){ ?>
					<!-- Right Box -->
					<div class="cta-three_image-column col-lg-6 col-md-12 col-sm-12">
						<div class="cta-three_image-outer">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
					</div>
					<?php } ?>
					<!-- Left Box -->
					<div class="cta-three_title-column col-lg-6 col-md-12 col-sm-12">
						<div class="cta-three_title-outer">
							<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                            <!-- Sec Title -->
							<div class="sec-title style-two light">
								<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
								<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
								<?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
							</div>
                            <?php } ?>
                            <?php if($settings[ 'btn_title']) {?>
							<div class="cta-two_button">
								<a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-three">
									<span class="btn-wrap">
										<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
										<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									</span>
								</a>
							</div>
                            <?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End CTA Three -->
    
    <?php elseif($settings['layout_control'] == '2') :?>
    
    <!-- CTA Two -->
	<section class="cta-two te-icon-box">
		<div class="auto-container">
			<div class="inner-container">
				<div class="row clearfix">
					<!-- Left Box -->
					<div class="cta-two_title-column col-lg-6 col-md-12 col-sm-12">
						<div class="cta-two_title-outer">
							<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                            <!-- Sec Title -->
							<div class="sec-title style-two light">
								<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
								<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
								<?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
							</div>
                            <?php } ?>
                            <?php if($settings[ 'btn_title']) {?>
							<div class="cta-two_button">
								<a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-three">
									<span class="btn-wrap">
										<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
										<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									</span>
								</a>
							</div>
                            <?php } ?>
						</div>
					</div>
                    <?php if($settings['image']['id']){ ?>
					<!-- Right Box -->
					<div class="cta-two_image-column col-lg-6 col-md-12 col-sm-12">
						<div class="cta-two_image-outer">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
					</div>
                    <?php } ?>
				</div>
			</div>
		</div>
	</section>
	<!-- End CTA Two -->
    
    <?php else: ?>
    
    <!-- Community One -->
	<section class="community-one te-icon-box">
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                <!-- Sec Title -->
				<div class="sec-title style-two centered">
					<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
					<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
				</div>
                <?php } ?>
                <?php if($settings[ 'form_url']) {?>
				<div class="newsletter-box">
					<?php echo do_shortcode($settings['form_url'], true);?>
				</div>
                <?php } ?>
                <?php $features_list = $settings['features_list'];
					if(!empty($features_list)){
					$features_list = explode("\n", ($features_list)); 
				?>
				<ul class="community-one_list">
					<?php foreach($features_list as $features): ?>
					   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
					<?php endforeach; ?>
				</ul>
				<?php } ?>
                <?php if($settings['image']['id']){ ?>
				<div class="community-one_image">
					<img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
				</div>
                <?php } ?>
			</div>
		</div>
	</section>
	<!-- End Community One -->	
    
    <?php endif; ?>  
    <?php 
    }
}