<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Blog_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_blog_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Blog Grid', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'blog_grid',
            [
                'label' => esc_html__( 'Blog Grid', 'braine' ),
            ]
        );
				
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
				),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'braine' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'braine' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'braine' ),
                    'title'      => esc_html__( 'Title', 'braine' ),
                    'menu_order' => esc_html__( 'Menu Order', 'braine' ),
                    'rand'       => esc_html__( 'Random', 'braine' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'braine' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'braine' ),
                    'ASC'  => esc_html__( 'ASC', 'braine' ),
                ),
            ]
        );
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default' => esc_html__( 'Read more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title', 'braine' ),
			]
		);
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'braine'),
				'label_block' => true,
                'options' => get_blog_categories(),
            ]
        );
		$this->add_control(
            'show_pagination',
			[
				'label' => __( 'Enable/Disable Pagination', 'braine' ),
				'type'     => Controls_Manager::SWITCHER,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['2'], ],
				'placeholder' => __( 'Enable/Disable Pagination', 'braine' ),
			]
		);
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		
		$paged = get_query_var('paged');
		$paged = braine_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-greenture' );
        $args = array(
            'post_type'      => 'post',
            'posts_per_page' => braine_set( $settings, 'query_number' ),
            'orderby'        => braine_set( $settings, 'query_orderby' ),
            'order'          => braine_set( $settings, 'query_order' ),
            'paged'         => $paged
        );
        if( braine_set( $settings, 'query_category' ) ) $args['category_name'] = braine_set( $settings, 'query_category' );
        $query = new \WP_Query( $args );
		if ( $query->have_posts() ) { 
	?>
    <?php if($settings['layout_control'] == '2') :?>
    
    <!-- News Three -->
	<section class="news-three te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
                <!-- News Block One -->
                <div class="news-block_one col-lg-4 col-md-6 col-sm-12">
                    <div class="news-block_one-inner">
                        <div class="news-block_one-image">
                            <a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_post_thumbnail('braine_380x250'); ?></a>
                        </div>
                        <div class="news-block_one-content">
                            <div class="news-block_one-time"><?php esc_html_e('By', 'braine');?> <?php the_author(); ?> <span><?php echo get_the_date( ); ?></span></div>
                            <h5 class="news-block_one-title"><a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h5>
                            <a class="news-block_one-more" href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php echo wp_kses($settings['btn_title'], true);?> <i class="fas fa-plus fa-fw"></i></a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
			</div>
            <?php if($settings['show_pagination']) { ?>
            <!-- Styled Pagination -->
			<div class="styled-pagination text-center">
				<?php braine_the_pagination2(array('total'=>$query->max_num_pages, 'next_text' => '<i class="fa fa-angle-right fa-fw"></i>', 'prev_text' => '<i class="fa fa-angle-left fa-fw"></i>')); ?>
			</div>
			<!-- End Styled Pagination -->
            <?php } ?>
        </div>
	</section>
	<!-- End News One -->
    
    <?php else: ?>
    
    <!-- News Two -->
	<section class="news-two te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <!-- Sec Title -->
			<div class="sec-title title-anim style-three light centered">
				<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
				<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
			</div>
            <?php } ?>
			<div class="inner-container">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
				<!-- News Block Two -->
				<div class="news-block_two">
					<div class="news-block_two-inner">
						<div class="d-flex justify-content-between align-items-center flex-wrap">
							<div class="news-block_two-content">
								<div class="news-block_one-time"><?php esc_html_e('By', 'braine');?> <?php the_author(); ?> <span><?php echo get_the_date(); ?></span></div>
								<h3 class="news-block_one-heading"><a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
							</div>
							<!-- Button Box -->
							<div class="news-block_two-button">
								<a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>" class="template-btn btn-style-two">
									<span class="btn-wrap">
										<span class="text-one"><?php echo wp_kses($settings['btn_title'], true);?></span>
										<span class="text-two"><?php echo wp_kses($settings['btn_title'], true);?></span>
									</span>
								</a>
							</div>
						</div>
						<div class="news-block_two-hover"><?php the_post_thumbnail('braine_380x380'); ?></div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
		</div>
	</section>
	<!-- End News Two -->    
   	
    <?php endif; ?>
   	<?php }
	wp_reset_postdata();
	}
}