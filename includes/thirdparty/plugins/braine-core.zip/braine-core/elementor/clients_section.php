<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Clients_Section extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_clients_section';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Clients Section', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
	
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'clients_section',
            [
                'label' => esc_html__( 'Clients Section', 'braine' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
				),
			]
		);
		
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'condition' => [ 'layout_control' => ['1', '2', '3'], ],
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
			]
		);
		
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'feature_image',
			[
				'label' => esc_html__( 'Client Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);	
		$repeater->add_control(
			'img_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'slide',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
			
		$this->end_controls_section();//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
			
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		
	?>
    
	<?php if($settings['layout_control'] == '3') :?>
    
    <!-- Clients Two -->
	<section class="clients-two style-two te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle']) {?>
            <!-- Sec Title -->
			<div class="sec-title centered">
				<div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div>
			</div>
            <?php } ?>
			<div class="clients_slider swiper-container">
				<div class="swiper-wrapper">
					<?php foreach($settings['slide'] as $key => $item): ?>
					<!-- Slide -->
					<div class="swiper-slide">
						<?php if($item[ 'feature_image' ]['id']){ ?>
                        <div class="client-image">
							<a href="<?php echo esc_url($item['img_link']['url']); ?>"><img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></a>
						</div>
                        <?php } ?>
					</div>
                    <?php endforeach; ?>
				</div>
			</div>
		</div>
	</section>
	<!-- End Clients Two -->
    
    <?php elseif($settings['layout_control'] == '2') :?>
	
	<!-- Clients Two -->
	<section class="clients-two te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle']) {?>
            <!-- Sec Title -->
			<div class="sec-title centered">
				<div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div>
			</div>
            <?php } ?>
			<div class="clients_slider swiper-container">
				<div class="swiper-wrapper">
					<?php foreach($settings['slide'] as $key => $item): ?>
					<!-- Slide -->
					<div class="swiper-slide">
						<?php if($item[ 'feature_image' ]['id']){ ?>
                        <div class="client-image">
							<a href="<?php echo esc_url($item['img_link']['url']); ?>"><img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></a>
						</div>
                        <?php } ?>
					</div>
                    <?php endforeach; ?>
				</div>
			</div>
		</div>
	</section>
	<!-- End Clients Two -->
	
	<?php else: ?>
        
	<!-- Clients One -->
	<section class="clients-one te-icon-box">
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                <div class="sec-title style-two light centered">
                    <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                    <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                </div>
                <?php } ?>
				<div class="clients-box_one">
					<div class="animation_mode">
						<?php foreach($settings['slide'] as $key => $item): ?>
						<!-- Client Box -->
						<div class="clients-box">
							<?php if($item[ 'feature_image' ]['id']){ ?>
                            <a href="<?php echo esc_url($item['img_link']['url']); ?>">
								<img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
							</a>
                            <?php } ?>
						</div>
                        <?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Clients One -->
        	
    	
    <?php endif; ?>
	<?php
    }
}