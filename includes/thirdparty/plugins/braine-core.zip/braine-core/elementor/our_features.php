<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Our_Features extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_our_features';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Our Features', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
		
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'our_features',
            [
                'label' => esc_html__( 'Our Features', 'braine' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
					'4' => esc_html__( 'Style Four ', 'braine'),
				),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [ 'layout_control' => ['1', '3'], ],
				'dynamic' => [ 'active' => true, ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(), ],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [ 'layout_control' => ['1', '3'], ],
				'dynamic' => [ 'active' => true, ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(), ],
			]
		);
		$this->add_control(
			'image3',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [ 'layout_control' => ['3'], ],
				'dynamic' => [ 'active' => true, ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(), ],
			]
		);
		
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2', '3', '4'], ],
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [ 'active' => true, ],
				'default' => esc_html__( 'How its work', 'braine' ),
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1', '2', '3', '4'], ],
				'label_block' => true,
				'default' => esc_html__( 'Braine <span>typically operate</span> in <br> a three steps', 'braine' ),
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
			]
		);
		
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '3', '4'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['1', '3', '4'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		
		$this->add_control(
			'feature_image2',
			[
				'label' => esc_html__( 'Feature Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [ 'layout_control' => ['1'], ],
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'block_counter2',
			[
				'label' => esc_html__( 'Counter', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [ 'layout_control' => ['1'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your counter', 'braine' ),
				'default' => esc_html__( 'Step 01', 'braine' ),
			]
		);
		$this->add_control(
			'block_title2',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [ 'layout_control' => ['1'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Algorithm processing', 'braine' ),
			]
		);
		$this->add_control(
			'block_text2',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Massa ipsum dolor sit ame consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna..', 'braine' ),
			]
		);		
		
		$repeater = new Repeater();
		$repeater->add_control(
			'feature_image',
			[
				'label' => esc_html__( 'Icon Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'block_counter',
			[
				'label' => esc_html__( 'Counter', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your counter', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_text',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);			
		$this->add_control(
			'slide',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['1'], ],
			]
		);
		
		$repeater = new Repeater();
		$repeater->add_control(
			'feature_image3',
			[
				'label' => esc_html__( 'Icon Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'feature_image4',
			[
				'label' => esc_html__( 'Pattern Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		//Icons		
		$repeater->add_control(
			'icon',
			[
				'label' => esc_html__('Enter The icons', 'braine'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'icon-mail',
					'library' => 'solid',
				],
			]			
		);
		$repeater->add_control(
			'block_title3',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_text3',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);	
		$repeater->add_control(
			'block_btn_title3',
			[
				'label' => esc_html__( 'Button Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Button Title', 'braine' ),
				'default' => esc_html__( 'Read more', 'braine' ),
			]
		);	
		$repeater->add_control(
			'ext_link3',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);	
		$this->add_control(
			'slide_v2',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['2'], ],
			]
		);
		
		$repeater = new Repeater();
		$repeater->add_control(
			'feature_image5',
			[
				'label' => esc_html__( 'Icon Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'block_title4',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_text4',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);	
		$repeater->add_control(
			'block_btn_title4',
			[
				'label' => esc_html__( 'Button Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Button Title', 'braine' ),
				'default' => esc_html__( 'Read more', 'braine' ),
			]
		);	
		$repeater->add_control(
			'ext_link4',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);	
		$this->add_control(
			'slide_v3',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['3'], ],
			]
		);
		
		$repeater = new Repeater();		
		//Icons		
		$repeater->add_control(
			'icon5',
			[
				'label' => esc_html__('Enter The icons', 'braine'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'icon-mail',
					'library' => 'solid',
				],
			]			
		);
		$repeater->add_control(
			'block_title5',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$repeater->add_control(
			'block_text5',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'slide_v5',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['4'], ],
			]
		);
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
			
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');		
	?>
    
	<?php if($settings['layout_control'] == '4' ):?>
    
    <!-- Value One -->
	<section class="value-one te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <div class="sec-title style-four centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="row clearfix">
				<?php $countss = 1; foreach($settings['slide_v5'] as $key => $item): ?>
				<!-- Value Block One -->
				<div class="value-block_one <?php if($countss == '2') echo 'active';?> col-lg-4 col-md-6 col-sm-12">
					<div class="value-block_one-inner">
						<?php
							$icon5 = $item['icon5'];
							if( !empty( $icon5 ) ):
						?>
                        <div class="value-block_one-icon">
							<?php \Elementor\Icons_Manager::render_icon( $icon5 ); ?>
						</div>
                        <?php endif;?>
						<h5 class="value-block_one-title"><?php echo wp_kses($item['block_title5'], true ) ;?></h5>
						<div class="value-block_one-text"><?php echo wp_kses($item['block_text5'], true ) ;?></div>
					</div>
				</div>
				<?php $countss++; endforeach; ?>
			</div>
			<?php if($settings[ 'btn_title']) {?>
			<!-- Button Box -->
			<div class="value-one_button text-center">
				<a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-two">
					<span class="btn-wrap">
						<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
						<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
					</span>
				</a>
			</div>
			<?php } ?>
		</div>
	</section>
	<!-- End Value One -->
    
    <?php elseif($settings['layout_control'] == '3' ):?>
    
    <!-- Tools One -->
	<section class="tools-one te-icon-box">
		<div class="tools-one_shadow" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
		<div class="tools-one_bg" <?php if($settings['image2']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"<?php } ?>></div>
		<div class="tools-one_bg-two" <?php if($settings['image3']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>)"<?php } ?>></div>
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <div class="sec-title style-two centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="animation_mode_three clearfix">
				<?php foreach($settings['slide_v3'] as $key => $item): ?>
				<!-- Social Block One -->
				<div class="social-block_one">
					<div class="social-block_one-inner">
						<?php if($item['feature_image5']['id']){ ?>
                        <div class="social-block_one-icon">
							<i><img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image5']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine');?>" /></i>
						</div>
                        <?php } ?>
						<h5 class="social-block_one-title"><a href="<?php echo esc_url($item['ext_link4']['url']); ?>"><?php echo wp_kses($item['block_title4'], true ) ;?></a></h5>
						<div class="social-block_one-text"><?php echo wp_kses($item['block_text4'], true ) ;?></div>
						<a class="social-block_one-more" href="<?php echo esc_url($item['ext_link4']['url']); ?>"><?php echo wp_kses($item['block_btn_title4'], true ) ;?> <i class="fas fa-plus fa-fw"></i></a>
					</div>
				</div>
                <?php endforeach; ?>
			</div>
			<?php if($settings[ 'btn_title']) {?>
			<div class="tools-one_button text-center">
				<a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
					<span class="btn-wrap">
						<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
						<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
					</span>
				</a>
			</div>
			<?php } ?>
		</div>
	</section>
	<!-- End Tools One -->
    
    <?php elseif($settings['layout_control'] == '2' ):?>
    
    <!-- Assistance One -->
	<section class="assistance-one te-icon-box">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <div class="sec-title style-two centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="three-item_carousel swiper-container">
				<div class="swiper-wrapper">
					<?php foreach($settings['slide_v2'] as $key => $item): ?>
					<!-- Slide -->
					<div class="swiper-slide">
						<!-- Service Block Three -->
						<div class="service-block_three">
							<div class="service-block_three-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
								<div class="service-block_three-dots" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($item['feature_image3']['id'])); ?>)"></div>
								<div class="service-block_three-circles" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($item['feature_image4']['id'])); ?>)"></div>
								<?php
									$icon = $item['icon'];
									if( !empty( $icon ) ):
								?>
                                <div class="color-layer"></div>								
                                <div class="service-block_three-icon">
									<?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
								</div>
                                <?php endif;?>
								<h5 class="service-block_three-heading"><a href="<?php echo esc_url($item['ext_link3']['url']); ?>"><?php echo wp_kses($item['block_title3'], true ) ;?></a></h5>
								<div class="service-block_three-text"><?php echo wp_kses($item['block_text3'], true ) ;?></div>
								<?php if($item['block_btn_title3']){ ?>
                                <a class="service-block_three-more" href="<?php echo esc_url($item['ext_link3']['url']); ?>"><?php echo wp_kses($item['block_btn_title3'], true ) ;?> <i class="fas fa-arrow-right fa-fw"></i></a>
                                <?php }; ?>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
				<!-- If we need pagination -->
				<div class="three-item_carousel-pagination"></div>
			</div>
		</div>
	</section>
	<!-- End Assistance One -->
    
    <?php else: ?>
    
	<!-- Steps One -->
	<section class="steps-one te-icon-box">
		<div class="steps-one_bg" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
		<div class="steps-one_icon" <?php if($settings['image2']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"<?php } ?>></div>
		<div class="auto-container">
			<div class="inner-container">
				<div class="circle-layer"></div>
				<div class="dots-layer">
					<span class="dot-one"></span>
					<span class="dot-two"></span>
				</div>
				<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                <div class="sec-title">
                    <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                    <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                </div>
                <?php } ?>
                <?php if($settings[ 'btn_title']) {?>
                <div class="steps-one_button">					
                    <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-two">
                        <span class="btn-wrap">
                            <span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
                            <span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
                        </span>
                    </a>                            
                </div>
                <?php } ?>
                
				<div class="row clearfix">
					<?php if($settings[ 'block_counter2'] || $settings[ 'block_title2'] || $settings[ 'block_text2'] || $settings['feature_image2']['id']) {?>
                    <!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<!-- Step Block One -->
						<div class="step-block_one">
							<div class="step-block_one-inner">
								<?php if($settings[ 'block_counter2']) {?><div class="step-block_one-steps"><?php echo wp_kses($settings['block_counter2'], true ) ;?></div><?php } ?>
								<?php if($settings[ 'block_title2']) {?><h5 class="step-block_one-title"><?php echo wp_kses($settings['block_title2'], true ) ;?></h5><?php } ?>
								<?php if($settings[ 'block_text2']) {?><div class="step-block_one-text"><?php echo wp_kses($settings['block_text2'], true ) ;?></div><?php } ?>
								<?php if($settings['feature_image2']['id']){ ?>
                                <div class="step-block_one-content">
									<div class="image">
										<img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
									</div>
								</div>
                                <?php } ?>
							</div>
						</div>
					</div>
                    <?php } ?>
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<?php foreach($settings['slide'] as $key => $item): ?>
						<!-- Step Block One -->
						<div class="step-block_one">
							<div class="step-block_one-inner">
								<div class="step-block_one-steps"><?php echo wp_kses($item['block_counter'], true ) ;?></div>
								<h5 class="step-block_one-title"><?php echo wp_kses($item['block_title'], true ) ;?></h5>
								<div class="step-block_one-text"><?php echo wp_kses($item['block_text'], true ) ;?></div>
								<?php if($item['feature_image']['id']){ ?>
                                <div class="step-block_one-content">
									<div class="image">
										<img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
									</div>
								</div>
                                <?php } ?>
							</div>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Steps One -->
    
    <?php endif; ?>  
    <?php 
    }
}