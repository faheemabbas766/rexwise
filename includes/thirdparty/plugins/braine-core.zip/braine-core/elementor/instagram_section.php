<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Instagram_Section extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_instagram_section';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Instagram Section', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
	
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'instagram_section',
            [
                'label' => esc_html__( 'Instagram Section', 'braine' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
				),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'image3',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'image4',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__( 'Sub Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your sub title', 'braine' ),
				'default' => esc_html__( 'Integrations', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Incorporate our tool into <br> <span>your everyday tasks</span>', 'braine' ),
			]
		);
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'feature_image',
			[
				'label' => esc_html__( 'Feature Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'image_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'slide',
			[
				'label'                 => __('Add Slide Item', 'braine'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);	
		
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['2'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['2'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);		
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
			
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		
	?>
    
    <?php if($settings['layout_control'] == '2') :?>
	
    <!-- Members One -->
	<section class="members-one te-icon-box" id="members-one">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <!-- Sec Title -->
            <div class="sec-title style-three centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="inner-container">
				<div class="members-carousel swiper-container">
					<div class="swiper-wrapper">
						<?php foreach($settings['slide'] as $key => $item): ?>
						<!-- Slide -->
						<div class="swiper-slide">
							<?php if($item['feature_image']['id']){ ?>
                            <!-- Member Block One -->
							<div class="member-block_one">
								<div class="member-block_one-inner">
									<div class="member-block_one-image">
										<img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
										<div class="member-block_one-overlay">
											<a href="<?php echo esc_url($item['image_link']['url'])?>" class="lightbox-video member-block_one-play"><span class="fas fa-play fa-fw"><i class="ripple"></i></span></a>
										</div>
									</div>
								</div>
							</div>
                            <?php } ?>
						</div>
                        <?php endforeach; ?>
					</div>
				</div>
				<?php if($settings[ 'btn_title']) {?>
				<div class="members-one_button text-center">
					<a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
						<span class="btn-wrap">
							<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
							<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
						</span>
					</a>
				</div>
				<?php } ?>
			</div>
		</div>
	</section>
	<!-- End Members One -->
    
	<?php else: ?>
    
    <!-- Social One -->
	<section class="social-one te-icon-box">
		<div class="social-one_bg-shadow" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <!-- Sec Title -->
            <div class="sec-title centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
            <?php if($settings['image2']['id']){ ?>
			<div class="social-one_logo">
				<span><img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></span>
			</div>
            <?php } ?>
			<div class="inner-container">
				<div class="social-one_bg" <?php if($settings['image3']['id']){ ?>style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>)"<?php } ?>></div>
				<div class="social-one_bg-two" <?php if($settings['image4']['id']){ ?>style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image4']['id'])); ?>)"<?php } ?>></div>
				
				<div class="social-box_one">
					<div class="animation_mode">
						<?php $count=0; foreach($settings['slide'] as $key => $item): ?>
                        <?php if(($count%7) == 0 && $count != 0):?>
					</div>
				</div>

				<div class="social-box">
					<div class="animation_mode_two">
						<?php endif; ?>
                        <!-- Icon -->
						<div class="social_icon-box">
							<a href="<?php echo esc_url($item['image_link']['url'])?>">
								<?php if($item['feature_image']['id']){ ?><img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /><?php } ?>
							</a>
						</div>
                        <?php $count++; endforeach; ?>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Social One -->        	
    	
    <?php endif; ?>
	
	<?php
    }
}