<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Service_Grid extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_service_grid';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Service Grid', 'braine' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-banner';
    }

    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }	
	
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'service_grid',
            [
                'label' => esc_html__( 'Service Grid', 'braine' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
				),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => esc_html__( 'Our Service', 'braine' ),
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Experience our latest <br> <span>new features</span>', 'braine' ),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
				'condition' => [  'layout_control' => ['1', '2'], ],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
				'condition' => [  'layout_control' => ['1', '2'], ],
			]
		);
		$this->add_control(
			'block_title',
			[
				'label' => esc_html__( 'Box Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'More service', 'braine' ),
			]
		);
		$this->add_control(
			'block_text',
			[
				'label' => esc_html__( 'Box Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'New features dolor sit ame consectetur.', 'braine' ),
			]
		);
		$this->add_control(
			'btns_titles',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'default' => esc_html__( 'Read More', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'braine' ),
				'type'    => Controls_Manager::NUMBER,				
				'default' => 15,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'braine' ),
					'title'      => esc_html__( 'Title', 'braine' ),
					'menu_order' => esc_html__( 'Menu Order', 'braine' ),
					'rand'       => esc_html__( 'Random', 'braine' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'braine' ),
					'ASC'  => esc_html__( 'ASC', 'braine' ),
				),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label' => esc_html__( 'Button Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter button title', 'braine' ),
				'default' => esc_html__('Read More', 'braine' ),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT2,
			  'label' => esc_html__('Category', 'braine'),
			  'label_block' => true,
			  'multiple' => true,
			  'options' => get_service_categories()
			]
		);
		$this->end_controls_section();
		
		/**Grid Setting Start**/
		$this->start_controls_section(
			'grid',
			[
				'label' => esc_html__( 'Grid Setting', 'braine' ),
			]
		);
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'braine' ),
				'label_block' => true,				
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'one' => esc_html__( 'One Column Grid ', 'braine'),
					'two'  => esc_html__( 'Two Column Grid', 'braine' ),
					'three'  => esc_html__( 'Three Column Grid', 'braine' ),
					'four'  => esc_html__( 'Four Column Grid', 'braine' ),
					'five'  => esc_html__( 'Six Column Grid', 'braine' ),
				),
			]
		);
		$this->end_controls_section();
			
		/**Layout Control Style**/		
		$this->start_controls_section(
			'braine_layout_style',
			[
				'label' => esc_html__('Inventive Layout Setting', 'braine'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'braine_layout_margin',
            [
                'label'              => __( 'Spacing', 'braine' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .braine-service' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;'
                ],
				'frontend_available' => true,
				
            ]
        );
		$this->add_responsive_control(
            'braine_layout_padding',
            [
                'label'              => __( 'Gapping', 'braine' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .braine-service' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;'
                ],
				'frontend_available' => true,
				
            ]
        );
		$this->add_control(
			'braine_layout_background',
			[
				'label'                 => __( 'Background', 'braine' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'braine_layout_bgtype',
				'label' => __( 'Button Background', 'braine' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .braine-service',				
			]
		);
		$this->end_controls_section();						
    }

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');	
		$grid_col = $settings['col_grid'];
		$btn_title = $settings['btn_title'];
		
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-6 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}
		
    	$paged = braine_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-braine' );
		$args = array(
			'post_type'      => 'service',
			'posts_per_page' => braine_set( $settings, 'query_number' ),
			'orderby'        => braine_set( $settings, 'query_orderby' ),
			'order'          => braine_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( braine_set( $settings, 'query_category' ) ) $args['service_cat'] = braine_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	{ ?>
    
    <?php if($settings['layout_control'] == '2'): ?>
    
    <!-- Services One -->
	<section class="services-one style-two bn-service-grid">
		<div class="auto-container">
			<div class="row clearfix">
				<?php
					$i = 1; 
					while ( $query->have_posts() ) : $query->the_post();                
				?>
				<!-- Service Block One -->
				<div class="service-block_one <?php echo esc_attr( $classes );?>">
					<div class="service-block_one-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="service-block_one-icon">
							<i class="<?php echo wp_kses(str_replace("icon ", " ", get_post_meta(get_the_id(), 'service_icon', true )), true); ?>"></i>
						</div>
						<h5 class="service-block_one-heading"><a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h5>
						<div class="service-block_one-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
						<div class="lower-box d-flex justify-content-between align-items-center flex-wrap">
							<div class="service-block_one-number"><?php $i = sprintf('%02d', $i); echo $i; ?></div>                            
							<a class="service-block_one-join" href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php echo wp_kses( $btn_title, true );?> <i class="fas fa-plus fa-fw"></i></a>
                        </div>
					</div>
				</div>
                <?php $i++; endwhile; ?> 
                
				<!-- Service Block Two -->
				<div class="service-block_two col-lg-4 col-md-6 col-sm-12">
					<div class="service-block_two-inner wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="service-block_two-sideicon" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
						<?php if($settings['image2']['id']){ ?>
                        <div class="service-block_two-icon">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
                        <?php } ?>
						<h5 class="service-block_two-heading"><a href="<?php echo esc_url($settings['btn_link']['url']) ;?>"><?php echo wp_kses($settings['block_title'], true ) ;?></a></h5>
						<div class="service-block_two-text"><?php echo wp_kses($settings['block_text'], true ) ;?></div>
						<?php if($settings[ 'btns_titles']) {?>
                        <div class="service-block_two-button">							
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btns_titles'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btns_titles'], true ) ;?></span>
								</span>
							</a>
						</div>
                        <?php } ?>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Services One -->  
       
    <?php else : ?>
    
    <!-- Services One -->
	<section class="services-one bn-service-grid">
		<div class="auto-container">
			<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
            <!-- Sec Title -->
            <div class="sec-title centered">
                <?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
                <?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
            </div>
            <?php } ?>
			<div class="row clearfix">
				<?php
					$i = 1; 
					while ( $query->have_posts() ) : $query->the_post();                
				?>
				<!-- Service Block One -->
				<div class="service-block_one <?php echo esc_attr( $classes );?>">
					<div class="service-block_one-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="service-block_one-icon">
							<i class="<?php echo wp_kses(str_replace("icon ", " ", get_post_meta(get_the_id(), 'service_icon', true )), true); ?>"></i>
						</div>
						<h5 class="service-block_one-heading"><a href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h5>
						<div class="service-block_one-text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
						<div class="lower-box d-flex justify-content-between align-items-center flex-wrap">
							<div class="service-block_one-number"><?php $i = sprintf('%02d', $i); echo $i; ?></div>                            
							<a class="service-block_one-join" href="<?php echo esc_url( get_the_permalink( get_the_id() ) );?>"><?php echo wp_kses( $btn_title, true );?> <i class="fas fa-plus fa-fw"></i></a>
                        </div>
					</div>
				</div>
                <?php $i++; endwhile; ?> 
                
				<!-- Service Block Two -->
				<div class="service-block_two col-lg-4 col-md-6 col-sm-12">
					<div class="service-block_two-inner wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="service-block_two-sideicon" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
						<?php if($settings['image2']['id']){ ?>
                        <div class="service-block_two-icon">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
                        <?php } ?>
						<h5 class="service-block_two-heading"><a href="<?php echo esc_url($settings['btn_link']['url']) ;?>"><?php echo wp_kses($settings['block_title'], true ) ;?></a></h5>
						<div class="service-block_two-text"><?php echo wp_kses($settings['block_text'], true ) ;?></div>
						<?php if($settings[ 'btns_titles']) {?>
                        <div class="service-block_two-button">							
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btns_titles'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btns_titles'], true ) ;?></span>
								</span>
							</a>
						</div>
                        <?php } ?>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- End Services One -->
    
    <?php endif; ?>
    <?php }
		wp_reset_postdata();
	}

}