<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Banner extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_banner';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Banner', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }	
	
	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'banner',
            [
                'label' => esc_html__( 'Banner', 'braine' ),
            ]
        );
		
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);		
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
				'default' => esc_html__( ' Effortless communication', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Intelligent <span>chat assistance</span> for your business', 'braine' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Hendrerit the dolor sit amet consectetur adipiscing elit Ut et massa <br> mi. Aliquam in hendrerit urna.', 'braine' ),
			]
		);
		$this->add_control(
			'form_url',
			[
				'label' => esc_html__( 'MailChimp Form Url', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your MailChimp Form Url', 'braine' ),
			]
		);
		$this->add_control(
			'features_list',
			[
				'label' => esc_html__( 'Feauter List', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Feauter List', 'braine' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'image3',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->add_control(
			'image4',
			[
				'label' => esc_html__( 'Feature Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true,],
				'default' => [ 'url' => Utils::get_placeholder_image_src(),	],
			]
		);
		$this->end_controls_section();
		
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
		
			
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
        
	<!-- Banner One -->
	<section class="banner-one te-icon-box">
		<?php if($settings['image']['id']){ ?><div class="banner-one_shadow" style="background-image: url('<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>')"></div><?php } ?>
		<div class="auto-container">
			<!-- Content Column -->
			<div class="banner-one_content">
				<div class="banner-one_content-inner">
					<?php if($settings[ 'subtitle'] || $settings['image2']['id']){ ?>
                    <div class="banner-one_title"><?php if($settings['image2']['id']){ ?><i><img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" /></i><?php } ?> <?php echo wp_kses($settings['subtitle'], true ) ;?></div>
					<?php };?>
                    <?php if($settings[ 'title']) {?><h1 class="banner-one_heading"><?php echo wp_kses($settings['title'], true ) ;?></h1><?php };?>
					<?php if($settings[ 'text']) {?><div class="banner-one_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php };?>
					<div class="banner-one_newsletter">
						<div class="newsletter-box">
							<?php echo do_shortcode($settings['form_url'], true);?>
						</div>
                        <?php $features_list = $settings['features_list'];
							if(!empty($features_list)){
							$features_list = explode("\n", ($features_list)); 
						?>
						<ul class="banner-one_list">
							<?php foreach($features_list as $features): ?>
							   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
							<?php endforeach; ?>
						</ul>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php if($settings['image3']['id']){ ?><div class="banner-one_icon" style="background-image: url('<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>')"></div><?php } ?>
			<?php if($settings['image4']['id']){ ?>
            <div class="banner-one_image">
				<img src="<?php echo esc_url(wp_get_attachment_url($settings['image4']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
			</div>
            <?php } ?>
		</div>
	</section>
	<!-- End Main Banner One -->
      
    <?php 
    }
}