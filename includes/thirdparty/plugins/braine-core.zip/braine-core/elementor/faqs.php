<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Faqs extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'braine_faqs';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Braine Faqs', 'braine' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'braine' ];
	}
		
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'faqs',
			[
				'label' => esc_html__( 'Braine Faqs', 'braine' ),
			]
		);
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Choose Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine' ),
					'3' => esc_html__( 'Style Three ', 'braine' ),
					'4' => esc_html__( 'Style Four ', 'braine' ),
				),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => __( 'Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' => __( 'Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'condition' => [ 'layout_control' => ['1', '2', '3', '4'], ],
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title Here', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1', '2', '3', '4'], ],
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title Here', 'braine' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'condition' => [ 'layout_control' => ['1', '3', '4'], ],
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text Here', 'braine' ),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '3', '4'], ],
				'default' => esc_html__( 'Know more', 'braine' ),
				'placeholder' => __( 'Enter your Button Title Here', 'braine' ),
			]
		);	
		$this->add_control(
			'btn_link',
			[
				'label' => __( 'External Link', 'braine' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'condition' => [ 'layout_control' => ['1', '3', '4'], ],
				'placeholder' => __( 'https://your-link.com', 'braine' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		//Post Array
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 15,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'braine' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'braine' ),
					'title'      => esc_html__( 'Title', 'braine' ),
					'menu_order' => esc_html__( 'Menu Order', 'braine' ),
					'rand'       => esc_html__( 'Random', 'braine' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'braine' ),
					'ASC'  => esc_html__( 'ASC', 'braine' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'braine'),
			  'label_block' => true,
			  'options' => get_faqs_categories()
			]
		);
		
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'braine' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'braine' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .te-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'braine' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .te-icon-box',				
			]
		);
		$this->end_controls_section();
						
	}

	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');		
		
    	$paged = braine_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-braine' );
		$args = array(
			'post_type'      => 'faqs',
			'posts_per_page' => braine_set( $settings, 'query_number' ),
			'orderby'        => braine_set( $settings, 'query_orderby' ),
			'order'          => braine_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( braine_set( $settings, 'query_category' ) ) $args['faqs_cat'] = braine_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	{ ?>
    
	<?php if($settings['layout_control'] == '4'): ?>
    
    <!-- Faq One -->
	<section class="faq-one style-four te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Tab Column -->
				<div class="faq-one_title-column col-lg-5 col-md-12 col-sm-12">
					<div class="faq-one_title-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                        <!-- Sec Title -->
						<div class="sec-title style-four">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                            <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
						</div>
                        <?php } ?>
                        <?php if($settings[ 'btn_title']) {?>
						<div class="faq-one_button">						
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
								</span>
							</a>                            
						</div>
                        <?php } ?>                        
					</div>
				</div>
				<!-- Accordian Column -->
				<div class="faq-one_accordian-column col-lg-7 col-md-12 col-sm-12">
					<div class="faq-one_accordian-outer">
						<!-- Accordion Box -->
						<ul class="accordion-box_two">
							<?php 
								while ( $query->have_posts() ) : $query->the_post();
							?>	
							<!-- Block -->
							<li class="accordion block">
								<div class="acc-btn"><div class="icon-outer"><span class="icon fas fa-plus fa-fw"></span></div><?php the_title(); ?></div>
								<div class="acc-content">
									<div class="content">
										<div class="text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
									</div>
								</div>
							</li>
							<?php endwhile; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Faq One -->
    
    <?php elseif($settings['layout_control'] == '3'): ?>
	
    <!-- Faq One -->
	<section class="faq-one style-two te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Tab Column -->
				<div class="faq-one_title-column col-lg-5 col-md-12 col-sm-12">
					<div class="faq-one_title-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                        <!-- Sec Title -->
						<div class="sec-title style-three title-anim light">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                            <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
						</div>
                        <?php } ?>
                        <?php if($settings[ 'btn_title']) {?>
						<div class="faq-one_button">						
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
								</span>
							</a>                            
						</div>
                        <?php } ?>                        
					</div>
				</div>
				<!-- Accordian Column -->
				<div class="faq-one_accordian-column col-lg-7 col-md-12 col-sm-12">
					<div class="faq-one_accordian-outer">
						<!-- Accordion Box -->
						<ul class="accordion-box_two">
							<?php 
								while ( $query->have_posts() ) : $query->the_post();
							?>	
							<!-- Block -->
							<li class="accordion block">
								<div class="acc-btn"><div class="icon-outer"><span class="icon fas fa-plus fa-fw"></span></div><?php the_title(); ?></div>
								<div class="acc-content">
									<div class="content">
										<div class="text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
									</div>
								</div>
							</li>
							<?php endwhile; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Faq One -->
    
	<?php elseif($settings['layout_control'] == '2'): ?>
    
    <!-- Order One -->
	<section class="order-one te-icon-box">
		<div class="auto-container">
			<div class="row clearfix">
				<?php if($settings['image']['id']){ ?>
                <!-- Column -->
				<div class="order-one_skill-column col-lg-6 col-md-12 col-sm-12">
					<div class="order-one_skill-outer">
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'braine'); ?>" />
						</div>
					</div>
				</div>
                <?php } ?>
				<!-- Column -->
				<div class="order-one_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="order-one_content-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title']) {?>
                        <!-- Sec Title -->
						<div class="sec-title style-two title-anim">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
						</div>
                        <?php } ?>
						<!-- Accordion Box Three -->
						<ul class="accordion-box_three">
							<?php 
								$jk = 1;
								while ( $query->have_posts() ) : $query->the_post();
							?>				
							<!-- Block -->
							<li class="accordion block <?php if($jk == 1) echo 'active-block';?>">
								<div class="acc-btn <?php if($jk == 1) echo 'active';?>">
									<div class="icon-outer">
										<span class="icon fas <?php echo wp_kses(str_replace("fa ", " ", get_post_meta(get_the_id(), 'faq_icon', true )), true); ?> fa-fw"></span>
									</div>
									<?php the_title(); ?>
								</div>
								<div class="acc-content <?php if($jk == 1) echo 'current';?>">
									<div class="content">
										<div class="text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
										<a class="learn-more" href="<?php echo esc_url(get_post_meta( get_the_id(), 'faq_read_more_btn_link', true)); ?>"><?php echo (get_post_meta( get_the_id(), 'faq_read_more_btn', true)); ?> <i class="fas fa-plus fa-fw"></i></a>
									</div>
								</div>
							</li>
                            <?php $jk++; endwhile; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Order One -->
    
    <?php else: ?>
    
	<!-- Faq One -->
	<section class="faq-one te-icon-box">
		<div class="faq-one_bg" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"></div>
		<div class="faq-one_icon" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Tab Column -->
				<div class="faq-one_title-column col-lg-5 col-md-12 col-sm-12">
					<div class="faq-one_title-outer">
						<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                        <!-- Sec Title -->
						<div class="sec-title title-anim">
							<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
							<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                            <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
						</div>
                        <?php } ?>
                        <?php if($settings[ 'btn_title']) {?>
						<div class="faq-one_button">						
                            <a href="<?php echo esc_url($settings['btn_link']['url']) ;?>" class="template-btn btn-style-one">
								<span class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
									<span class="text-two"><?php echo wp_kses($settings['btn_title'], true ) ;?></span>
								</span>
							</a>                            
						</div>
                        <?php } ?>                        
					</div>
				</div>
				<!-- Accordian Column -->
				<div class="faq-one_accordian-column col-lg-7 col-md-12 col-sm-12">
					<div class="faq-one_accordian-outer">
						<!-- Accordion Box -->
						<ul class="accordion-box_two">
							<?php 
								while ( $query->have_posts() ) : $query->the_post();
							?>	
							<!-- Block -->
							<li class="accordion block">
								<div class="acc-btn"><div class="icon-outer"><span class="icon fas fa-plus fa-fw"></span></div><?php the_title(); ?></div>
								<div class="acc-content">
									<div class="content">
										<div class="text"><?php echo wp_kses(wp_trim_words(get_the_content(), $settings['text_limit']), true); ?></div>
									</div>
								</div>
							</li>
							<?php endwhile; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Faq One -->
    
	<?php endif; ?>  
	<?php }
		wp_reset_postdata();
	}

}
		