<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Form extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_form';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Form', 'braine' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }
	
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'form',
            [
                'label' => esc_html__( 'Form', 'braine' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
				),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title ', 'braine' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2'], ],
				'default' => esc_html__( 'Contact me', 'braine' ),
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2', '3'], ],
				'placeholder' => esc_html__( 'Enter your title', 'braine' ),
				'default' => esc_html__( 'Feel free to ask any <span>questions</span> here', 'braine' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'braine' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1', '2', '3'], ],
				'placeholder' => esc_html__( 'Enter your text', 'braine' ),
				'default' => esc_html__( 'Aliquam amet dolor sit amet consectetur adipiscing <br> elit Ut et massa Aliquam in hendrerit urna.', 'braine' ),
			]
		);
		$this->add_control(
			'phone_title',
			[
				'label' => esc_html__( 'Phone Title', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => esc_html__( 'Enter your phone title', 'braine' ),
				'default' => esc_html__( 'Phone', 'braine' ),
			]
		);
		$this->add_control(
			'phone_no',
			[
				'label' => esc_html__( 'Phone Number', 'braine' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [ 'layout_control' => ['1'], ],
				'placeholder' => esc_html__( 'Enter your phone number', 'braine' ),
				'default' => esc_html__( '+1-678-772-6710', 'braine' ),
			]
		);
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'icons',
			[
				'label' => esc_html__('Enter The icons', 'inventive'),
				'label_block' => true,
				'type' => Controls_Manager::SELECT2,
				'options'  => get_fontawesome_icons(),
			]
		);
		$repeater->add_control(
			'social_link',
			[
				'label' => __( 'External Link', 'inventive' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'inventive' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);	
		$this->add_control(
			'slide_v10',
			[
				'label'                 => __('Add Social Icon Item', 'inventive'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [ 'layout_control' => ['2'], ],
			]
		);
		
		$this->add_control(
            'cf7_shortocde_v3',
            [
                'label' => esc_html__('Select Contact Form 7', 'braine'),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => get_contact_form_7_list(),
            ]
        );
				
		$this->end_controls_section();		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
    
    <?php if($settings['layout_control'] == '3') :?>
    
    <!-- Register One -->
	<section class="register-one">
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings[ 'title']) {?><h3><?php echo wp_kses($settings['title'], true ) ;?></h3><?php } ?>
				<?php if($settings[ 'text']) {?><div class="text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
				<?php if($settings[ 'cf7_shortocde_v3']) {?>
				<!-- Register Form -->
				<div class="register-form">
					<?php echo do_shortcode('[contact-form-7 id="'.esc_attr($settings['cf7_shortocde_v3']).'"]'); ?>
				</div>
				<!-- End Default Form -->
				<?php } ?>
			</div>
		</div>
	</section>
	<!-- End Register One -->
    
	<?php elseif($settings['layout_control'] == '2') :?>
    
    <!-- Team Detail Form -->
	<section class="team-detail_form">
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Column -->
				<div class="column col-lg-6 col-md-12 col-sm-12">
					<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                    <!-- Sec Title -->
					<div class="sec-title style-four">
						<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
						<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                        <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
					</div>
                    <?php } ?>
					<!-- Social Box -->
					<div class="contact-social_box">
						<?php 
							foreach($settings['slide_v10'] as $key => $item):
						?>
                        <a href="<?php echo esc_url($item['social_link']['url']); ?>"><i class="fab <?php echo wp_kses(str_replace( "fa ",  "", $item['icons']), true);?>"></i></a>
						<?php endforeach; ?>
					</div>
				</div>
                <?php if($settings[ 'cf7_shortocde_v3']) {?>
				<!-- Column -->
				<div class="column col-lg-6 col-md-12 col-sm-12">
					<div class="default-form contact-form">
						<?php echo do_shortcode('[contact-form-7 id="'.esc_attr($settings['cf7_shortocde_v3']).'"]'); ?>
					</div>
				</div>
                <?php } ?>
			</div>
		</div>
	</section>
	<!-- End Team Detail Form -->
	
	<?php else: ?>
    
    <!-- Team Detail Form -->
	<section class="team-detail_form">
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Column -->
				<div class="column col-lg-6 col-md-12 col-sm-12">
					<?php if($settings[ 'subtitle'] || $settings[ 'title'] || $settings[ 'text']) {?>
                    <!-- Sec Title -->
					<div class="sec-title style-four">
						<?php if($settings[ 'subtitle']) {?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true ) ;?></div><?php } ?>
						<?php if($settings[ 'title']) {?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true ) ;?></h2><?php } ?>
                        <?php if($settings[ 'text']) {?><div class="sec-title_text"><?php echo wp_kses($settings['text'], true ) ;?></div><?php } ?>
					</div>
                    <?php } ?>
                    <?php if($settings[ 'phone_title'] || $settings[ 'phone_no']) {?>
					<div class="faq-phone_box">
						<span class="icon fas fa-phone fa-fw"></span>
						<?php echo wp_kses($settings['phone_title'], true ) ;?> <?php if($settings[ 'phone_no']) {?><br>
						<a href="tel:<?php echo esc_attr($settings['phone_no']) ;?>"><?php echo wp_kses($settings['phone_no'], true ) ;?></a><?php } ?>
					</div>
                    <?php } ?>
				</div>
                <?php if($settings[ 'cf7_shortocde_v3']) {?>
				<!-- Column -->
				<div class="column col-lg-6 col-md-12 col-sm-12">
					<div class="default-form">
						<?php echo do_shortcode('[contact-form-7 id="'.esc_attr($settings['cf7_shortocde_v3']).'"]'); ?>
					</div>
				</div>
                <?php } ?>
			</div>
		</div>
	</section>
	<!-- End Team Detail Form -->
    
            
    <?php endif; ?>
	
	<?php
    }
}