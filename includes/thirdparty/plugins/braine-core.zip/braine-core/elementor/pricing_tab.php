<?php namespace BRAINEPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Pricing_Tab extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'braine_pricing_tab';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Braine Pricing Tab', 'braine' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-price-table';
    }

    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'braine' ];
    }

    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        //Yearly Tab Start		
		$this->start_controls_section(
            'generaly_tab_yearly',
            [
                'label' => esc_html__( 'General', 'braine' ),
            ]
        );
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'braine' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'braine'),
					'2' => esc_html__( 'Style Two ', 'braine'),
					'3' => esc_html__( 'Style Three ', 'braine'),
					'4' => esc_html__( 'Style Four ', 'braine'),
					'5' => esc_html__( 'Style Five ', 'braine'),
				),
			]
		);
		
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Shape Image', 'braine' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true, ],
				'condition' => [ 'layout_control' => ['1'], ],
				'default' => [ 'url' => Utils::get_placeholder_image_src(), ],
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2', '3', '5'], ],
				'default'     => __( 'Our Peicing', 'braine' ),
				'placeholder' => __( 'Enter your Sub Title', 'braine' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2', '3', '5'], ],
				'default'     => __( 'Join for <span>free</span> Today', 'braine' ),
				'placeholder' => __( 'Enter your title', 'braine' ),
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
            'pricing_tab_monthly',
            [
                'label' => esc_html__( 'Monthly', 'braine' ),
				'condition' => [ 'layout_control' => ['1', '2', '3', '4', '5'], ],
            ]
        );
		$this->add_control(
			'm_title',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [ 'layout_control' => ['1', '2', '3'], ],
				'default'     => __( 'Monthly', 'braine' ),
				'placeholder' => __( 'Enter your Title', 'braine' ),
			]
		);
		
		$this->start_controls_tabs( 'braine_tabs_package_plans' );
			
			//Tab Control Start
			$this->start_controls_tab(
				'braine_tab_left_panel',
				[
					'label' => __( 'Monthly', 'braine' ),
				]
			);
			
			$repeater = new Repeater();
			$repeater->add_control(
				'icon',
				[
					'label' => esc_html__('Enter The icons', 'braine'),
					'label_block' => true,
 					'type' => Controls_Manager::SELECT2,
					'options'  => get_fontawesome_icons(),
				]
			);
			$repeater->add_control(
				'icon_image',
				[
					'label' => __( 'Icon Image', 'braine' ),
					'type' => Controls_Manager::MEDIA,
					'default' => ['url' => Utils::get_placeholder_image_src(),],
				]
			);
			$repeater->add_control(
				'tab_title',
				[
					'label'       => __( 'Tab Title', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your tab title here', 'braine' ),
				]
			);
						
			$repeater->add_control(
				'tab_text',
				[
					'label'       => __( 'Text', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( 'Up to 2,000 words / mo', 'braine' ),
					'placeholder' => __( 'Enter your text here', 'braine' ),
				]
			);
			$repeater->add_control(
				'tab_price',
				[
					'label'       => __( 'Price', 'braine' ),
					'type'        => Controls_Manager::TEXTAREA,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( '<sup>$</sup>3<sub>/mo</sub>', 'braine' ),
					'placeholder' => __( 'Enter your price here', 'braine' ),
				]
			);	
			$repeater->add_control(
				'tab_text2',
				[
					'label'       => __( 'Description', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( '*Get Braine tailored', 'braine' ),
					'placeholder' => __( 'Enter your description here', 'braine' ),
				]
			);
			$repeater->add_control(
				'tab_btn_title',
				[
					'label'       => __( 'Button Title', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( 'Start 1 month free trail', 'braine' ),
					'placeholder' => __( 'Enter your description here', 'braine' ),
				]
			);		
			$repeater->add_control(
				'tab_btn_link',
				[
					'label' => __( 'External Link', 'braine' ),
					'type' => Controls_Manager::URL,
					'label_block' => true, 
					'placeholder' => __( 'https://your-link.com', 'braine' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);
			$repeater->add_control(
				'features_list',
				[
					'label'       => __( 'Feature List', 'braine' ),
					'type'        => Controls_Manager::TEXTAREA,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your Feature List here', 'braine' ),
				]
			);	
			$this->add_control(
				'monthly_list',
				[
					'label'                 => __('Add Monthly Item', 'braine'),
					'type'                  => Controls_Manager::REPEATER,
					'fields'                => $repeater->get_controls(),
					'title_field' => '{{{ tab_title }}}',
					'default' => [
						[
							'tab_title' => esc_html__( 'Starter', 'braine' ),
						],
						[
							'tab_title' => esc_html__( 'Professional', 'braine' ),
						],
						[
							'tab_title' => esc_html__( 'Enterprise', 'braine' ),
						],
					],
				]
			);
			
			$this->end_controls_tab();			
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		//Yearly Tab Start
		
		$this->start_controls_section(
            'pricing_tab_yearly',
            [
                'label' => esc_html__( 'Yearly', 'braine' ),
				'condition' => [ 'layout_control' => ['1', '2', '3', '5'], ],
            ]
        );
		$this->add_control(
			'y_title',
			[
				'label'       => __( 'Title', 'braine' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => __( 'Yearly', 'braine' ),
				'placeholder' => __( 'Enter your Title', 'braine' ),
			]
		);
		
		$this->start_controls_tabs( 'braine_tabs_yearly_package_plans' );
			
			//Tab Control Start
			$this->start_controls_tab(
				'braine_yearly_left_panel',
				[
					'label' => __( 'Yearly', 'braine' ),
				]
			);
			
			$repeater = new Repeater();
			$repeater->add_control(
				'icons',
				[
					'label' => esc_html__('Enter The icons', 'braine'),
					'label_block' => true,
 					'type' => Controls_Manager::SELECT2,
					'options'  => get_fontawesome_icons(),
				]
			);
			$repeater->add_control(
				'icon_images',
				[
					'label' => __( 'Icon Image', 'braine' ),
					'type' => Controls_Manager::MEDIA,
					'default' => ['url' => Utils::get_placeholder_image_src(),],
				]
			);
			$repeater->add_control(
				'tab_titles',
				[
					'label'       => __( 'Tab Title', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your tab title here', 'braine' ),
				]
			);
						
			$repeater->add_control(
				'tab_texts',
				[
					'label'       => __( 'Text', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( 'Up to 2,000 words / mo', 'braine' ),
					'placeholder' => __( 'Enter your text here', 'braine' ),
				]
			);
			$repeater->add_control(
				'tab_prices',
				[
					'label'       => __( 'Price', 'braine' ),
					'type'        => Controls_Manager::TEXTAREA,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( '<sup>$</sup>3<sub>/mo</sub>', 'braine' ),
					'placeholder' => __( 'Enter your price here', 'braine' ),
				]
			);	
			$repeater->add_control(
				'tab_texts2',
				[
					'label'       => __( 'Description', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( '*Get Braine tailored', 'braine' ),
				]
			);
			$repeater->add_control(
				'tab_btn_titles',
				[
					'label'       => __( 'Button Title', 'braine' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => __( 'Start 1 month free trail', 'braine' ),
					'placeholder' => __( 'Enter your description here', 'braine' ),
				]
			);		
			$repeater->add_control(
				'tab_btn_links',
				[
					'label' => __( 'External Link', 'braine' ),
					'type' => Controls_Manager::URL,
					'label_block' => true, 
					'placeholder' => __( 'https://your-link.com', 'braine' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);
			$repeater->add_control(
				'features_lists',
				[
					'label'       => __( 'Feature List', 'braine' ),
					'type'        => Controls_Manager::TEXTAREA,
					'label_block' => true,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your Feature List here', 'braine' ),
				]
			);	
			$this->add_control(
				'yearly_list',
				[
					'label'                 => __('Add Yealy Item', 'braine'),
					'type'                  => Controls_Manager::REPEATER,
					'fields'                => $repeater->get_controls(),
					'title_field' => '{{{ tab_titles }}}',
					'default' => [
						[
							'tab_titles' => esc_html__( 'Starter', 'braine' ),
						],
						[
							'tab_titles' => esc_html__( 'Professional', 'braine' ),
						],
						[
							'tab_titles' => esc_html__( 'Enterprise', 'braine' ),
						],
					],
				]
			);
			
			$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
	}

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		
    ?>
    
	<?php if($settings['layout_control'] == '5' ):?>
    
    <!-- Price One -->
	<section class="price-three">
		<div class="auto-container">
			<div class="inner-container">				
				<div class="pricing-tabs tabs-box">					
					<!--Tab Btns-->
					<div class="buttons-outer">
						<ul class="tab-buttons clearfix">
							<li data-tab="#prod-monthly" class="tab-btn active-btn"><?php echo wp_kses( $settings[ 'm_title' ], true );?></li>
							<li data-tab="#prod-yearly" class="tab-btn"><?php echo wp_kses( $settings[ 'y_title' ], true );?></li>
						</ul>
					</div>
					<!--Tabs Container-->
					<div class="tabs-content">
						
						<!-- Tab -->
						<div class="tab active-tab" id="prod-monthly">
							<div class="content">
								<div class="row clearfix">
									<?php  $ask = 1; foreach( $settings[ 'monthly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<div class="price-block_one <?php if($ask == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_one-inner">
											<?php if($ask == 2) : ?>
                                            <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($item['icon_image']['id'])); ?>)"></div>
											<?php endif; ?>
                                            <div class="price-block_one-title"><?php echo wp_kses( $item[ 'tab_title' ], true );?></div>
											<div class="price-block_one-subtitle"><?php echo wp_kses( $item[ 'tab_text' ], true );?></div>
											<div class="price-block_one-content">
												<div class="d-flex justify-content-between align-items-end flex-wrap">
													<div class="price-block_one-price"><?php echo wp_kses( $item[ 'tab_price' ], true );?></div>
													<div class="price-block_one-text"><?php echo wp_kses( $item[ 'tab_text2' ], true );?></div>
												</div>
                                                <?php if($item[ 'tab_btn_title' ]){ ?>
												<div class="price-block_one-button">
													<a class="template-btn price-one_button" href="<?php echo esc_url( $item[ 'tab_btn_link' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_title' ], true );?></a>
												</div>
                                                <?php } ?>
                                                <?php $features_list = $item['features_list'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_one-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
											</div>
										</div>
									</div>
									<?php $ask++; endforeach;?>
								</div>
							</div>
						</div>

						<!-- Tab -->
						<div class="tab" id="prod-yearly">
							<div class="content">
								<div class="row clearfix">
									<?php $ajs = 1; foreach( $settings[ 'yearly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<!-- Price Block One -->
									<div class="price-block_one <?php if($ajs == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_one-inner">
											<?php if($ajs == 2) : ?>
                                            <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($item['icon_images']['id'])); ?>)"></div>
											<?php endif; ?>
                                            <div class="price-block_one-title"><?php echo wp_kses( $item[ 'tab_titles' ], true );?></div>
											<div class="price-block_one-subtitle"><?php echo wp_kses( $item[ 'tab_texts' ], true );?></div>
											<div class="price-block_one-content">
												<div class="d-flex justify-content-between align-items-end flex-wrap">
													<div class="price-block_one-price"><?php echo wp_kses( $item[ 'tab_prices' ], true );?></div>
													<div class="price-block_one-text"><?php echo wp_kses( $item[ 'tab_texts2' ], true );?></div>
												</div>
                                                <?php if($item[ 'tab_btn_titles' ]){ ?>
												<div class="price-block_one-button">
													<a class="template-btn price-one_button" href="<?php echo esc_url( $item[ 'tab_btn_links' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_titles' ], true );?></a>
												</div>
                                                <?php } ?>
                                                <?php $features_list = $item['features_lists'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_one-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
											</div>
										</div>
									</div>
									<?php $ajs++; endforeach;?>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>
	</section>
	<!-- End Price One -->
    
	<?php elseif($settings['layout_control'] == '4' ):?>
    
    <!-- Price One -->
	<section class="price-four">
		<div class="auto-container">
            <div class="row clearfix">
                <?php  $ask = 1; foreach( $settings[ 'monthly_list' ] as $key => $item ): ?>
                <!-- Price Block One -->
                <div class="price-block_one <?php if($ask == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
                    <div class="price-block_one-inner">
                        <?php if($ask == 2) : ?>
                        <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($item['icon_image']['id'])); ?>)"></div>
                        <?php endif; ?>
                        <div class="price-block_one-title"><?php echo wp_kses( $item[ 'tab_title' ], true );?></div>
                        <div class="price-block_one-subtitle"><?php echo wp_kses( $item[ 'tab_text' ], true );?></div>
                        <div class="price-block_one-content">
                            <div class="d-flex justify-content-between align-items-end flex-wrap">
                                <div class="price-block_one-price"><?php echo wp_kses( $item[ 'tab_price' ], true );?></div>
                                <div class="price-block_one-text"><?php echo wp_kses( $item[ 'tab_text2' ], true );?></div>
                            </div>
                            <?php if($item[ 'tab_btn_title' ]){ ?>
                            <div class="price-block_one-button">
                                <a class="template-btn price-one_button" href="<?php echo esc_url( $item[ 'tab_btn_link' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_title' ], true );?></a>
                            </div>
                            <?php } ?>
                            <?php $features_list = $item['features_list'];
                                if(!empty($features_list)){
                                $features_list = explode("\n", ($features_list)); 
                            ?>
                            <ul class="price-block_one-list">
                                <?php foreach($features_list as $features): ?>
                                   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php $ask++; endforeach;?>
            </div>
		</div>
	</section>
	<!-- End Price One -->
    
    <?php elseif($settings['layout_control'] == '3' ):?>
    
    <!-- Price One -->
	<section class="price-two style-two">
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings['subtitle'] || $settings['title']) { ?>
                <div class="sec-title style-three centered">
                    <?php if($settings['subtitle']) { ?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true);?></div><?php } ?>
                    <?php if($settings['title']) { ?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
                </div>
                <?php } ?>
				<div class="pricing-tabs tabs-box">					
					<!--Tab Btns-->
					<div class="buttons-outer">
						<ul class="tab-buttons clearfix">
							<li data-tab="#prod-monthly" class="tab-btn active-btn"><?php echo wp_kses( $settings[ 'm_title' ], true );?></li>
							<li data-tab="#prod-yearly" class="tab-btn"><?php echo wp_kses( $settings[ 'y_title' ], true );?></li>
						</ul>
					</div>
					<!--Tabs Container-->
					<div class="tabs-content">
						
						<!-- Tab -->
						<div class="tab active-tab" id="prod-monthly">
							<div class="content">
								<div class="row clearfix">
									<?php  $ask = 1; foreach( $settings[ 'monthly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<div class="price-block_two <?php if($ask == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_two-inner">
											<div class="price-block_two-icon fas <?php echo wp_kses(str_replace( "fa ",  "", $item['icon']), true);?> fa-fw"></div>
                                            <div class="price-block_two-title"><?php echo wp_kses( $item[ 'tab_title' ], true );?></div>
											<div class="price-block_two-subtitle"><?php echo wp_kses( $item[ 'tab_text' ], true );?></div>
											<div class="price-block_two-content">
                                                <div class="price-block_two-price"><?php echo wp_kses( $item[ 'tab_price' ], true );?></div>
                                                <?php $features_list = $item['features_list'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_two-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
                                                <?php if($item[ 'tab_btn_title' ]){ ?>
												<div class="price-block_two-button">
													<a class="template-btn price-two_button" href="<?php echo esc_url( $item[ 'tab_btn_link' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_title' ], true );?></a>
												</div>
                                                <?php } ?>
											</div>
										</div>
									</div>
									<?php $ask++; endforeach;?>
								</div>
							</div>
						</div>

						<!-- Tab -->
						<div class="tab" id="prod-yearly">
							<div class="content">
								<div class="row clearfix">
									<?php $ajs = 1; foreach( $settings[ 'yearly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<!-- Price Block One -->
									<div class="price-block_two <?php if($ajs == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_two-inner">
											<div class="price-block_two-icon fas <?php echo wp_kses(str_replace( "fa ",  "", $item['icons']), true);?> fa-fw"></div>
                                            <div class="price-block_two-title"><?php echo wp_kses( $item[ 'tab_titles' ], true );?></div>
											<div class="price-block_two-subtitle"><?php echo wp_kses( $item[ 'tab_texts' ], true );?></div>
											<div class="price-block_two-content">
                                                <div class="price-block_two-price"><?php echo wp_kses( $item[ 'tab_prices' ], true );?></div>
                                                <?php $features_list = $item['features_lists'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_two-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
                                                <?php if($item[ 'tab_btn_titles' ]){ ?>
												<div class="price-block_two-button">
													<a class="template-btn price-two_button" href="<?php echo esc_url( $item[ 'tab_btn_links' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_titles' ], true );?></a>
												</div>
                                                <?php } ?>
											</div>
										</div>
									</div>
									<?php $ajs++; endforeach;?>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>
	</section>
	<!-- End Price One -->
    
    <?php elseif($settings['layout_control'] == '2' ):?>
    
    <!-- Price One -->
	<section class="price-two">
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings['subtitle'] || $settings['title']) { ?>
                <div class="sec-title style-two">
                    <?php if($settings['subtitle']) { ?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true);?></div><?php } ?>
                    <?php if($settings['title']) { ?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
                </div>
                <?php } ?>
				<div class="pricing-tabs tabs-box">					
					<!--Tab Btns-->
					<div class="buttons-outer">
						<ul class="tab-buttons clearfix">
							<li data-tab="#prod-monthly" class="tab-btn active-btn"><?php echo wp_kses( $settings[ 'm_title' ], true );?></li>
							<li data-tab="#prod-yearly" class="tab-btn"><?php echo wp_kses( $settings[ 'y_title' ], true );?></li>
						</ul>
					</div>
					<!--Tabs Container-->
					<div class="tabs-content">
						
						<!-- Tab -->
						<div class="tab active-tab" id="prod-monthly">
							<div class="content">
								<div class="row clearfix">
									<?php  $ask = 1; foreach( $settings[ 'monthly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<div class="price-block_one style-two <?php if($ask == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_one-inner">
											<?php if($ask == 2) : ?>
                                            <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($item['icon_image']['id'])); ?>)"></div>
											<?php endif; ?>
                                            <div class="price-block_one-title"><?php echo wp_kses( $item[ 'tab_title' ], true );?></div>
											<div class="price-block_one-subtitle"><?php echo wp_kses( $item[ 'tab_text' ], true );?></div>
											<div class="price-block_one-content">
												<div class="d-flex justify-content-between align-items-end flex-wrap">
													<div class="price-block_one-price"><?php echo wp_kses( $item[ 'tab_price' ], true );?></div>
													<div class="price-block_one-text"><?php echo wp_kses( $item[ 'tab_text2' ], true );?></div>
												</div>                                                
                                                <?php $features_list = $item['features_list'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_one-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
                                                <?php if($item[ 'tab_btn_title' ]){ ?>
												<div class="price-block_one-button">
													<a class="template-btn price-one_button" href="<?php echo esc_url( $item[ 'tab_btn_link' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_title' ], true );?></a>
												</div>
                                                <?php } ?>
											</div>
										</div>
									</div>
									<?php $ask++; endforeach;?>
								</div>
							</div>
						</div>

						<!-- Tab -->
						<div class="tab" id="prod-yearly">
							<div class="content">
								<div class="row clearfix">
									<?php $ajs = 1; foreach( $settings[ 'yearly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<!-- Price Block One -->
									<div class="price-block_one style-two <?php if($ajs == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_one-inner">
											<?php if($ajs == 2) : ?>
                                            <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($item['icon_images']['id'])); ?>)"></div>
											<?php endif; ?>
                                            <div class="price-block_one-title"><?php echo wp_kses( $item[ 'tab_titles' ], true );?></div>
											<div class="price-block_one-subtitle"><?php echo wp_kses( $item[ 'tab_texts' ], true );?></div>
											<div class="price-block_one-content">
												<div class="d-flex justify-content-between align-items-end flex-wrap">
													<div class="price-block_one-price"><?php echo wp_kses( $item[ 'tab_prices' ], true );?></div>
													<div class="price-block_one-text"><?php echo wp_kses( $item[ 'tab_texts2' ], true );?></div>
												</div>                                                
                                                <?php $features_list = $item['features_lists'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_one-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
                                                <?php if($item[ 'tab_btn_titles' ]){ ?>
												<div class="price-block_one-button">
													<a class="template-btn price-one_button" href="<?php echo esc_url( $item[ 'tab_btn_links' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_titles' ], true );?></a>
												</div>
                                                <?php } ?>
											</div>
										</div>
									</div>
									<?php $ajs++; endforeach;?>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>
	</section>
	<!-- End Price One -->
    
    <?php else: ?>
    
    <!-- Price One -->
	<section class="price-one">
		<div class="price-one_bg" <?php if($settings['image']['id']){ ?> style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>)"<?php } ?>></div>
		<div class="auto-container">
			<div class="inner-container">
				<?php if($settings['subtitle'] || $settings['title']) { ?>
                <div class="sec-title title-anim centered">
                    <?php if($settings['subtitle']) { ?><div class="sec-title_title"><?php echo wp_kses($settings['subtitle'], true);?></div><?php } ?>
                    <?php if($settings['title']) { ?><h2 class="sec-title_heading"><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
                </div>
                <?php } ?>
				<div class="pricing-tabs tabs-box">					
					<!--Tab Btns-->
					<div class="buttons-outer">
						<ul class="tab-buttons clearfix">
							<li data-tab="#prod-monthly" class="tab-btn active-btn"><?php echo wp_kses( $settings[ 'm_title' ], true );?></li>
							<li data-tab="#prod-yearly" class="tab-btn"><?php echo wp_kses( $settings[ 'y_title' ], true );?></li>
						</ul>
					</div>
					<!--Tabs Container-->
					<div class="tabs-content">
						
						<!-- Tab -->
						<div class="tab active-tab" id="prod-monthly">
							<div class="content">
								<div class="row clearfix">
									<?php  $ask = 1; foreach( $settings[ 'monthly_list' ] as $key => $item ): ?>
									<!-- Price Block One -->
									<div class="price-block_one <?php if($ask == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_one-inner">
											<?php if($ask == 2) : ?>
                                            <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($item['icon_image']['id'])); ?>)"></div>
											<?php endif; ?>
                                            <div class="price-block_one-title"><?php echo wp_kses( $item[ 'tab_title' ], true );?></div>
											<div class="price-block_one-subtitle"><?php echo wp_kses( $item[ 'tab_text' ], true );?></div>
											<div class="price-block_one-content">
												<div class="d-flex justify-content-between align-items-end flex-wrap">
													<div class="price-block_one-price"><?php echo wp_kses( $item[ 'tab_price' ], true );?></div>
													<div class="price-block_one-text"><?php echo wp_kses( $item[ 'tab_text2' ], true );?></div>
												</div>
                                                <?php if($item[ 'tab_btn_title' ]){ ?>
												<div class="price-block_one-button">
													<a class="template-btn price-one_button" href="<?php echo esc_url( $item[ 'tab_btn_link' ]['url'] );?>"><?php echo wp_kses( $item[ 'tab_btn_title' ], true );?></a>
												</div>
                                                <?php } ?>
                                                <?php $features_list = $item['features_list'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_one-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
											</div>
										</div>
									</div>
									<?php $ask++; endforeach;?>
								</div>
							</div>
						</div>

						<!-- Tab -->
						<div class="tab" id="prod-yearly">
							<div class="content">
								<div class="row clearfix">
									<?php $ajs = 1; foreach( $settings[ 'yearly_list' ] as $key => $items ): ?>
									<!-- Price Block One -->
									<!-- Price Block One -->
									<div class="price-block_one <?php if($ajs == 2) echo 'active'; else echo ''; ?> col-lg-4 col-md-6 col-sm-12">
										<div class="price-block_one-inner">
											<?php if($ajs == 2) : ?>
                                            <div class="price-one_stars" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($items['icon_images']['id'])); ?>)"></div>
											<?php endif; ?>
                                            <div class="price-block_one-title"><?php echo wp_kses( $items[ 'tab_titles' ], true );?></div>
											<div class="price-block_one-subtitle"><?php echo wp_kses( $items[ 'tab_texts' ], true );?></div>
											<div class="price-block_one-content">
												<div class="d-flex justify-content-between align-items-end flex-wrap">
													<div class="price-block_one-price"><?php echo wp_kses( $items[ 'tab_prices' ], true );?></div>
													<div class="price-block_one-text"><?php echo wp_kses( $items[ 'tab_texts2' ], true );?></div>
												</div>
                                                <?php if($items[ 'tab_btn_titles' ]){ ?>
												<div class="price-block_one-button">
													<a class="template-btn price-one_button" href="<?php echo esc_url( $items[ 'tab_btn_links' ]['url'] );?>"><?php echo wp_kses( $items[ 'tab_btn_titles' ], true );?></a>
												</div>
                                                <?php } ?>
                                                <?php $features_list = $items['features_lists'];
													if(!empty($features_list)){
													$features_list = explode("\n", ($features_list)); 
												?>
												<ul class="price-block_one-list">
													<?php foreach($features_list as $features): ?>
													   <li><i class="fas fa-check fa-fw"></i><?php echo wp_kses($features, true); ?></li>
													<?php endforeach; ?>
												</ul>
												<?php } ?>
											</div>
										</div>
									</div>
									<?php $ajs++; endforeach;?>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>
	</section>
	<!-- End Price One -->
	
    <?php endif; ?>  
        <?php
    }
}
