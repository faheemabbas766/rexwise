<?php
return array(
	'title'      => 'Braine Team Setting',
	'id'         => 'braine_meta_team',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'team' ),
	'sections'   => array(
		array(
			'id'     => 'braine_team_meta_setting',
			'fields' => array(
				array(
					'id'    => 'team_top_heading',
					'type'  => 'text',
					'title' => esc_html__( 'Heading', 'braine' ),
				),
				array(
					'id'    => 'designation',
					'type'  => 'text',
					'title' => esc_html__( 'Designation', 'braine' ),
				),
				array(
					'id'    => 'team_email_title',
					'type'  => 'text',
					'title' => esc_html__( 'Email Title', 'braine' ),
				),
				array(
					'id'    => 'team_email_address',
					'type'  => 'text',
					'title' => esc_html__( 'Email Address', 'braine' ),
				),
				array(
					'id'    => 'team_address_title',
					'type'  => 'text',
					'title' => esc_html__( 'Address Title', 'braine' ),
				),
				array(
					'id'    => 'team_address',
					'type'  => 'text',
					'title' => esc_html__( 'Address', 'braine' ),
				),
				array(
					'id'    => 'team_phone_title',
					'type'  => 'text',
					'title' => esc_html__( 'Phone Title', 'braine' ),
				),
				array(
					'id'    => 'team_phone_no',
					'type'  => 'text',
					'title' => esc_html__( 'Phone Number', 'braine' ),
				),
				array(
					'id'    => 'team_exp_title',
					'type'  => 'text',
					'title' => esc_html__( 'Experience Title', 'braine' ),
				),
				array(
					'id'    => 'team_experience',
					'type'  => 'text',
					'title' => esc_html__( 'Experience', 'braine' ),
				),
				array(
					'id'    => 'team_btn_title',
					'type'  => 'text',
					'title' => esc_html__( 'Contact Button Title', 'braine' ),
				),
				array(
					'id'    => 'team_btn_link',
					'type'  => 'text',
					'title' => esc_html__( 'Contact Button Url', 'braine' ),
				),
				array(
					'id'        => 'social_media_tabs',
					'type'      => 'repeater',
					'icon' => 'el-icon-thumbs-up',
					'title'     => __('Add Social Media', 'braine'),
					'group_values' => true,
					'sortable' => true,
					'fields'    => array(
						array(
							'id' => 'select_social_media',
							'type' => 'select',
							'data' => get_fontawesome_icons(),
							'title' => esc_html__('Choose Social Media', 'braine'),
						),
						array(
							'id'      => 'link_social_media',
							'type'    => 'text',
							'title'   => __('Text', 'braine'),
						),
					)
				),
				array(
					'id'    => 'show_experience_section',
					'type'  => 'switch',
					'title' => esc_html__( 'Enable Experience Section', 'braine' ),
					'default'  => false,
				),
				array(
					'id'    => 'team_experience_subtitle',
					'type'  => 'text',
					'required' => array( 'show_experience_section', '=', true ),
					'title' => esc_html__( 'Experience Sub Title', 'braine' ),
				),
				array(
					'id'    => 'team_experience_title',
					'type'  => 'text',
					'required' => array( 'show_experience_section', '=', true ),
					'title' => esc_html__( 'Experience Title', 'braine' ),
				),
				array(
					'id'    => 'team_experience_text',
					'type'  => 'textarea',
					'required' => array( 'show_experience_section', '=', true ),
					'title' => esc_html__( 'Experience Text', 'braine' ),
				),
				array(
					'id'        => 'team_exp_tabs',
					'type'      => 'repeater',
					'icon' => 'el-icon-thumbs-up',
					'required' => array( 'show_experience_section', '=', true ),
					'title'     => __('Add Info Item', 'braine'),
					'group_values' => true,
					'sortable' => true,
					'fields'    => array(
						array(
							'id'      => 'team_exp_funfact_title',
							'type'    => 'text',
							'title'   => __('Experience Tab Title', 'braine'),
						),
						array(
							'id'      => 'team_exp_start',
							'type'    => 'text',
							'title'   => __('Start Value', 'braine'),
						),
						array(
							'id'      => 'team_exp_stop',
							'type'    => 'text',
							'title'   => __('Stop Value', 'braine'),
						),
						array(
							'id'      => 'team_exp_alphabet',
							'type'    => 'text',
							'title'   => __('Alphabet Letter', 'braine'),
						),						
					)
				),
				array(
					'id'    => 'show_team_contact_form',
					'type'  => 'switch',
					'title' => esc_html__( 'Enable Contact Form Section', 'braine' ),
					'default'  => false,
				),
				array(
					'id'    => 'team_contact_subtitle',
					'type'  => 'text',
					'required' => array( 'show_team_contact_form', '=', true ),
					'title' => esc_html__( 'Contact Sub Title', 'braine' ),
				),
				array(
					'id'    => 'team_contact_title',
					'type'  => 'text',
					'required' => array( 'show_team_contact_form', '=', true ),
					'title' => esc_html__( 'Contact Title', 'braine' ),
				),
				array(
					'id'    => 'team_contact_text',
					'type'  => 'textarea',
					'required' => array( 'show_team_contact_form', '=', true ),
					'title' => esc_html__( 'Contact Text', 'braine' ),
				),
				array(
					'id'    => 'team_contact_form_url',
					'type'  => 'text',
					'required' => array( 'show_team_contact_form', '=', true ),
					'title' => esc_html__( 'Contact Form Url', 'braine' ),
				),
			),
		),
	),
);