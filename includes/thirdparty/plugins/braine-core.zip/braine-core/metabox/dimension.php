<?php

	return array(
		'title'      => 'braine post Setting',
		'id'         => 'braine_post',
		'icon'       => 'el el-cogs',
		'position'   => 'normal',
		'priority'   => 'core',
		'post_types' => array( 'post' ),
		'sections'   => array(
			array(
				'fields' => array(
					array(
						'id'    => 'blog_dimension',
						'type'  => 'select',
						'title' => esc_html__( 'Choose the Extra height', 'braine' ),
						'options'  => array(
							'normal_height' => esc_html__( 'Normal Height', 'braine' ),
							'extra_height' => esc_html__( 'Extra Height', 'braine' ),
							'extra_width' => esc_html__( 'Extra Width', 'braine' ),
						),
						'default'  => 'normal_height',
					),				
				),
			),
		),
	);
?>