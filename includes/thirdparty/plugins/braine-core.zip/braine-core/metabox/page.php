<?php
return array(
	'title'      => 'Braine Setting',
	'id'         => 'braine_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'page', 'post', 'team', 'service', 'testimonials', 'faqs'),
	'sections'   => array(
		require_once BRAINEPLUGIN_PLUGIN_PATH . '/metabox/header.php',
		require_once BRAINEPLUGIN_PLUGIN_PATH . '/metabox/banner.php',
		require_once BRAINEPLUGIN_PLUGIN_PATH . '/metabox/sidebar.php',
		require_once BRAINEPLUGIN_PLUGIN_PATH . '/metabox/footer.php',
	),
);