<?php
return array(
	'title'      => 'Braine Faq Setting',
	'id'         => 'braine_meta_faqs',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'faqs' ),
	'sections'   => array(
		array(
			'id'     => 'braine_faqs_meta_setting',
			'fields' => array(
				array(
					'id'       => 'faq_icon',
					'type'     => 'select',
					'title'    => esc_html__( 'Faq Icons', 'braine' ),
					'options'  => get_fontawesome_icons(),
				),
				array(
					'id'    => 'faq_read_more_btn',
					'type'  => 'text',
					'title' => esc_html__( 'Read More Title', 'braine' ),
				),
				array(
					'id'    => 'faq_read_more_btn_link',
					'type'  => 'text',
					'title' => esc_html__( 'Read More Link', 'braine' ),
				),
			),
		),
	),
);