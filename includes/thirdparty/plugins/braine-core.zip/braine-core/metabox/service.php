<?php
return array(
	'title'      => 'Braine Service Setting',
	'id'         => 'braine_meta_service',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'service' ),
	'sections'   => array(
		array(
			'id'     => 'braine_service_meta_setting',
			'fields' => array(
				//Icons
				array(
					'id'       => 'service_icon',
					'type'     => 'select',
					'title'    => esc_html__( 'Service Icons', 'braine' ),
					'options'  => get_fontawesome_icons(),
				),
				//Top Info
				array(
					'id'    => 'service_subtitle',
					'type'  => 'text',
					'title' => esc_html__( 'Sub Title', 'braine' ),
				),
				array(
					'id'    => 'service_designation',
					'type'  => 'textarea',
					'title' => esc_html__( 'Designation', 'braine' ),
				),
				array(
					'id'    => 'service_top_description',
					'type'  => 'textarea',
					'title' => esc_html__( 'Top Description', 'braine' ),
				),	
				array(
					'id'    => 'service_detail_image',
					'type'  => 'media',
					'title' => esc_html__( 'Detail Image', 'braine' ),
				),
				//Benefit Section
				array(
					'id'    => 'show_benefit_section',
					'type'  => 'switch',
					'title' => esc_html__( 'Enable Benefit Section', 'braine' ),
					'default'  => false,
				),
				array(
					'id'    => 'service_benefit_subtitle',
					'type'  => 'text',
					'required' => array( 'show_benefit_section', '=', true ),
					'title' => esc_html__( 'Benefit Sub Title', 'braine' ),
				),
				array(
					'id'    => 'service_benefit_title',
					'type'  => 'text',
					'required' => array( 'show_benefit_section', '=', true ),
					'title' => esc_html__( 'Benefit Title', 'braine' ),
				),
				array(
					'id'        => 'service_benefit_tabs',
					'type'      => 'repeater',
					'icon' => 'el-icon-thumbs-up',
					'required' => array( 'show_benefit_section', '=', true ),
					'title'     => __('Add Info Item', 'braine'),
					'group_values' => true,
					'sortable' => true,
					'fields'    => array(
						array(
							'id' => 'select_benefit_tab_icon',
							'type' => 'select',
							'data' => get_fontawesome_icons(),
							'title' => esc_html__('Choose Icons', 'braine'),
						),
						array(
							'id'      => 'tab_benefit_title',
							'type'    => 'text',
							'title'   => __('Benefit Tab Title', 'braine'),
						),
						array(
							'id'      => 'tab_benefit_text',
							'type'    => 'textarea',
							'title'   => __('Benefit Tab Text', 'braine'),
						),						
					)
				),	
				//How Its Work Section		
				array(
					'id'    => 'show_steps_section',
					'type'  => 'switch',
					'title' => esc_html__( 'Enable How Its Work Section', 'braine' ),
					'default'  => false,
				),
				array(
					'id'    => 'service_steps_image',
					'type'  => 'media',
					'required' => array( 'show_steps_section', '=', true ),
					'title' => esc_html__( 'Background Image', 'braine' ),
				),
				array(
					'id'    => 'service_steps_subtitle',
					'type'  => 'text',
					'required' => array( 'show_steps_section', '=', true ),
					'title' => esc_html__( 'How Its Work Sub Title', 'braine' ),
				),
				array(
					'id'    => 'service_steps_title',
					'type'  => 'text',
					'required' => array( 'show_steps_section', '=', true ),
					'title' => esc_html__( 'How Its Work Title', 'braine' ),
				),
				array(
					'id'    => 'service_steps_btn_title',
					'type'  => 'text',
					'required' => array( 'show_steps_section', '=', true ),
					'title' => esc_html__( 'Button Title', 'braine' ),
				),
				array(
					'id'    => 'service_steps_btn_link',
					'type'  => 'text',
					'required' => array( 'show_steps_section', '=', true ),
					'title' => esc_html__( 'Button Link', 'braine' ),
				),
				//Problem Section
				array(
					'id'    => 'show_problems_section',
					'type'  => 'switch',
					'title' => esc_html__( 'Enable Problem Section', 'braine' ),
					'default'  => false,
				),				
				array(
					'id'    => 'service_problems_subtitle',
					'type'  => 'text',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Title', 'braine' ),
				),
				array(
					'id'    => 'service_problems_title',
					'type'  => 'text',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Title', 'braine' ),
				),
				array(
					'id'    => 'service_problems_text',
					'type'  => 'textarea',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Text', 'braine' ),
				),
				array(
					'id'    => 'service_features_list',
					'type'  => 'textarea',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Feature List', 'braine' ),
				),
				array(
					'id'    => 'service_problems_image',
					'type'  => 'media',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Image', 'braine' ),
				),
				array(
					'id'    => 'service_problems_video_image',
					'type'  => 'media',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Video BG Image', 'braine' ),
				),
				array(
					'id'    => 'service_problems_video_link',
					'type'  => 'text',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Video Link', 'braine' ),
				),
				array(
					'id'    => 'service_problems_subtitle2',
					'type'  => 'text',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Title', 'braine' ),
				),
				array(
					'id'    => 'service_problems_title2',
					'type'  => 'text',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Title', 'braine' ),
				),
				array(
					'id'    => 'service_problems_text2',
					'type'  => 'textarea',
					'required' => array( 'show_problems_section', '=', true ),
					'title' => esc_html__( 'Problem Text', 'braine' ),
				),
				//FAQ'S Section		
				array(
					'id'    => 'show_faq_section',
					'type'  => 'switch',
					'title' => esc_html__( 'Enable FAQ Section', 'braine' ),
					'default'  => false,
				),
				array(
					'id'    => 'service_faq_subtitle',
					'type'  => 'text',
					'required' => array( 'show_faq_section', '=', true ),
					'title' => esc_html__( 'FAQ Sub Title', 'braine' ),
				),
				array(
					'id'    => 'service_faq_title',
					'type'  => 'text',
					'required' => array( 'show_faq_section', '=', true ),
					'title' => esc_html__( 'FAQ Title', 'braine' ),
				),
				array(
					'id'    => 'service_faq_text',
					'type'  => 'textarea',
					'required' => array( 'show_faq_section', '=', true ),
					'title' => esc_html__( 'FAQ Description', 'braine' ),
				),
				array(
					'id'    => 'service_faq_btn_title',
					'type'  => 'text',
					'required' => array( 'show_faq_section', '=', true ),
					'title' => esc_html__( 'FAQ Button Title', 'braine' ),
				),
				array(
					'id'    => 'service_faq_btn_link',
					'type'  => 'text',
					'required' => array( 'show_faq_section', '=', true ),
					'title' => esc_html__( 'FAQ Button Link', 'braine' ),
				),
				array(
					'id'        => 'service_faqs_tabs',
					'type'      => 'repeater',
					'icon' => 'el-icon-thumbs-up',
					'required' => array( 'show_faq_section', '=', true ),
					'title'     => __('Add Info Item', 'braine'),
					'group_values' => true,
					'sortable' => true,
					'fields'    => array(
						array(
							'id'      => 'tab_faq_title',
							'type'    => 'text',
							'title'   => __('Faq Tab Title', 'braine'),
						),
						array(
							'id'      => 'tab_faq_text',
							'type'    => 'textarea',
							'title'   => __('Faq Tab Text', 'braine'),
						),						
					)
				),
				//Servuce Tags
				array(
					'id'        => 'service_feature_tags_tab',
					'type'      => 'repeater',
					'icon' => 'el-icon-thumbs-up',
					'title'     => __('Add Info Item', 'braine'),
					'group_values' => true,
					'sortable' => true,
					'fields'    => array(
						array(
							'id'      => 'service_tags_titls',
							'type'    => 'text',
							'title'   => __('Tags Title', 'braine'),
						),
						array(
							'id'      => 'service_tags_link',
							'type'    => 'text',
							'title'   => __('Tags Link', 'braine'),
						),						
					)
				),
				//Service Social Media
				array(
					'id'        => 'service_social_media_tabs',
					'type'      => 'repeater',
					'icon' => 'el-icon-thumbs-up',
					'title'     => __('Add Info Item', 'braine'),
					'group_values' => true,
					'sortable' => true,
					'fields'    => array(
						array(
							'id' => 'select_service_social_media',
							'type' => 'select',
							'data' => get_fontawesome_icons(),
							'title' => esc_html__('Choose Social Media', 'braine'),
						),
						array(
							'id'      => 'service_link_social_media',
							'type'    => 'text',
							'title'   => __('Social Media Link', 'braine'),
						),						
					)
				),
			),
		),
	),
);