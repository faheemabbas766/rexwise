<?php

return array(
	'id'     => 'braine_banner_settings',
	'title'  => esc_html__( "Braine Banner Settings", "braine" ),
	'fields' => array(
		array(
			'id'      => 'banner_source_type',
			'type'    => 'button_set',
			'title'   => esc_html__( 'Banner Source Type', 'braine' ),
			'options' => array(
				'd' => esc_html__( 'Default', 'braine' ),
				'e' => esc_html__( 'Elementor', 'braine' ),
			),
			'default' => '',
		),
		array(
			'id'       => 'banner_elementor_template',
			'type'     => 'select',
			'title'    => __( 'Template', 'viral-buzz' ),
			'data'     => 'posts',
			'args'     => [
				'post_type' => [ 'elementor_library' ],
				'posts_per_page'=> -1,
			],
			'required' => [ 'banner_source_type', '=', 'e' ],
		),
		array(
			'id'       => 'banner_page_banner',
			'type'     => 'switch',
			'title'    => esc_html__( 'Show Banner', 'braine' ),
			'default'  => false,
			'required' => [ 'banner_source_type', '=', 'd' ],
		),
		array(
			'id'       => 'banner_banner_title',
			'type'     => 'text',
			'title'    => esc_html__( 'Banner Section Title', 'braine' ),
			'desc'     => esc_html__( 'Enter the title to show in banner section', 'braine' ),
			'required' => array( 'banner_page_banner', '=', true ),
		),
		array(
			'id'       => 'banner_icon_image',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Banner Icon Shape Image Left', 'braine' ),
			'desc'     => esc_html__( 'Insert icon shape image for banner', 'braine' ),			
			'required' => array( 'banner_page_banner', '=', true ),
		),
		array(
			'id'       => 'banner_icon_image2',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Banner Icon Shape Image Right', 'braine' ),
			'desc'     => esc_html__( 'Insert icon shape image for banner', 'braine' ),			
			'required' => array( 'banner_page_banner', '=', true ),
		),
		array(
			'id'       => 'banner_page_background',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Background Image', 'braine' ),
			'desc'     => esc_html__( 'Insert background image for banner', 'braine' ),
			'required' => array( 'banner_page_banner', '=', true ),
		),
		array(
			'id'       => 'banner_shape_image',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Banner Shape Image', 'braine' ),
			'desc'     => esc_html__( 'Insert shape image for banner', 'braine' ),			
			'required' => array( 'banner_page_banner', '=', true ),
		),
	),
);