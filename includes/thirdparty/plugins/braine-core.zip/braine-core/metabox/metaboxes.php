<?php
if ( ! function_exists( "braine_add_metaboxes" ) ) {
	function braine_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'dimension.php',
			'service.php',
			'faq.php',
			'testimonials.php',
			'team.php',
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( BRAINEPLUGIN_PLUGIN_PATH . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/braine_options/boxes", "braine_add_metaboxes" );
}

