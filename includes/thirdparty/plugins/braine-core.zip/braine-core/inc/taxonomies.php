<?php

namespace BRAINEPLUGIN\Inc;


use BRAINEPLUGIN\Inc\Abstracts\Taxonomy;


class Taxonomies extends Taxonomy {


	public static function init() {

		//Services Taxonomy Start
		$labels = array(
			'name'              => _x( 'Service Category', 'wpbraine' ),
			'singular_name'     => _x( 'Service Category', 'wpbraine' ),
			'search_items'      => __( 'Search Category', 'wpbraine' ),
			'all_items'         => __( 'All Categories', 'wpbraine' ),
			'parent_item'       => __( 'Parent Category', 'wpbraine' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpbraine' ),
			'edit_item'         => __( 'Edit Category', 'wpbraine' ),
			'update_item'       => __( 'Update Category', 'wpbraine' ),
			'add_new_item'      => __( 'Add New Category', 'wpbraine' ),
			'new_item_name'     => __( 'New Category Name', 'wpbraine' ),
			'menu_name'         => __( 'Service Category', 'wpbraine' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'service_cat' ),
		);


		register_taxonomy( 'service_cat', 'service', $args );		
				
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wpbraine' ),
			'singular_name'     => _x( 'Testimonials Category', 'wpbraine' ),
			'search_items'      => __( 'Search Category', 'wpbraine' ),
			'all_items'         => __( 'All Categories', 'wpbraine' ),
			'parent_item'       => __( 'Parent Category', 'wpbraine' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpbraine' ),
			'edit_item'         => __( 'Edit Category', 'wpbraine' ),
			'update_item'       => __( 'Update Category', 'wpbraine' ),
			'add_new_item'      => __( 'Add New Category', 'wpbraine' ),
			'new_item_name'     => __( 'New Category Name', 'wpbraine' ),
			'menu_name'         => __( 'Testimonials Category', 'wpbraine' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);


		register_taxonomy( 'testimonials_cat', 'testimonials', $args );
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wpbraine' ),
			'singular_name'     => _x( 'Team Category', 'wpbraine' ),
			'search_items'      => __( 'Search Category', 'wpbraine' ),
			'all_items'         => __( 'All Categories', 'wpbraine' ),
			'parent_item'       => __( 'Parent Category', 'wpbraine' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpbraine' ),
			'edit_item'         => __( 'Edit Category', 'wpbraine' ),
			'update_item'       => __( 'Update Category', 'wpbraine' ),
			'add_new_item'      => __( 'Add New Category', 'wpbraine' ),
			'new_item_name'     => __( 'New Category Name', 'wpbraine' ),
			'menu_name'         => __( 'Team Category', 'wpbraine' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);


		register_taxonomy( 'team_cat', 'team', $args );
		
		//Faqs Taxonomy Start
		$labels = array(
			'name'              => _x( 'Faqs Category', 'wpbraine' ),
			'singular_name'     => _x( 'Faqs Category', 'wpbraine' ),
			'search_items'      => __( 'Search Category', 'wpbraine' ),
			'all_items'         => __( 'All Categories', 'wpbraine' ),
			'parent_item'       => __( 'Parent Category', 'wpbraine' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpbraine' ),
			'edit_item'         => __( 'Edit Category', 'wpbraine' ),
			'update_item'       => __( 'Update Category', 'wpbraine' ),
			'add_new_item'      => __( 'Add New Category', 'wpbraine' ),
			'new_item_name'     => __( 'New Category Name', 'wpbraine' ),
			'menu_name'         => __( 'Faqs Category', 'wpbraine' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'faqs_cat' ),
		);


		register_taxonomy( 'faqs_cat', 'faqs', $args );
			
		
	}
	
}
