<?php

///----footer widgets---
//Newsletter Form
class Braine_Newsletter_Form extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Braine_Newsletter_Form', /* Name */esc_html__('Braine Newsletter Form','braine'), array( 'description' => esc_html__('Show the Newsletter Form', 'braine' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		echo wp_kses_post($before_widget);?>
        
        <div class="footer-newsletter">
            <?php if($instance['footer_title']) { ?><h5 class="footer-title"><?php echo wp_kses( $instance[ 'footer_title' ], true );?></h5><?php } ?>
            <?php if($instance['footer_content']) { ?><div class="footer-newsletter_text"><?php echo wp_kses( $instance[ 'footer_content' ], true );?></div><?php } ?>
            <?php if($instance['footer_form_url']) { ?>
            <div class="newsletter-box">
                <?php echo do_shortcode( $instance[ 'footer_form_url' ], true );?>
            </div>
            <?php } ?>
        </div>
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['footer_title'] = $new_instance['footer_title'];		
		$instance['footer_content'] = $new_instance['footer_content'];
		$instance['footer_form_url'] = $new_instance['footer_form_url'];
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$footer_title = ($instance) ? esc_attr($instance['footer_title']) : 'Newsletter';		
		$footer_content = ($instance) ? esc_attr($instance['footer_content']) : 'Vitae mattis dolor sit amet consectetur adipiscing vitae mattis tellus. Nullam quis mattis.';
		$footer_form_url = ($instance) ? esc_attr($instance['footer_form_url']) : '[mc4wp_form id=171]';
	?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('footer_title')); ?>"><?php esc_html_e('Title: ', 'braine'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_title')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_title')); ?>" type="text" value="<?php echo esc_attr( $footer_title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('footer_content')); ?>"><?php esc_html_e('Content:', 'braine'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_content')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_content')); ?>" ><?php echo wp_kses_post($footer_content); ?></textarea>
        </p>        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('footer_form_url')); ?>"><?php esc_html_e('Newsletter Form Url: ', 'braine'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_form_url')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_form_url')); ?>" type="text" value="<?php echo esc_attr( $footer_form_url ); ?>" />
        </p>
        
    <?php 
	}
	
}


//Blog Widgets
//Recent Posts
class Braine_Recent_Posts extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Braine_Recent_Posts', /* Name */esc_html__('Braine Recent Posts','braine'), array( 'description' => esc_html__('Show the Recent Posts', 'braine' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

		echo wp_kses_post($before_widget); ?>
		
        <div class="post-widget">
            <div class="widget-content">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
				<?php $query_string = array('showposts'=>$instance['number']);
                if ($instance['cat']) {
                    $query_string['tax_query'] = array(array('taxonomy' => 'category','field' => 'id','terms' => (array)$instance['cat']));
                }
                $this->posts($query_string); ?>
            </div>
        </div>
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/* @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/* @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Recent Posts', 'braine');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'braine'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'braine'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'braine'); ?></label>
            <?php wp_dropdown_categories(array('show_option_all'=>esc_html__('All Categories', 'braine'), 'taxonomy' => 'category', 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('cat'))); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				while ( $query->have_posts() ) : $query->the_post();
			?>
            <div class="post">
                <div class="thumb"><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_post_thumbnail('braine_90x90'); ?></a></div>
                <h6><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h6>
                <div class="post-date"><i class="fas fa-calendar fa-fw"></i> <?php echo get_the_date('');?></div>
            </div>
                        
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}


